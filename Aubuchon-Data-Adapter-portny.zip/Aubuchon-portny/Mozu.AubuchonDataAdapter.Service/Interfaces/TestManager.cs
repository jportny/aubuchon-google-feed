﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mozu.AubuchonDataAdapter.Service.Interfaces
{
    public interface ITestManager 
    {
        void Print();
    }
    public class TestManager : ITestManager
    {

        public void Print()
        {
            
        }
    }
}
