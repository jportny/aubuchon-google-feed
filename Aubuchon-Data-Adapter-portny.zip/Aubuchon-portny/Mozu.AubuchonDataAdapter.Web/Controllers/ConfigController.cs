﻿using System.Web.Mvc;

namespace Mozu.AubuchonDataAdapter.Web.Controllers
{
    public class ConfigController : Controller
    {
        // GET: Config
        public ActionResult Index()
        {
            return View();
        }
    }
}