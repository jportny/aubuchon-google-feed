﻿namespace Mozu.AubuchonDataAdapter.Web.Models
{
    public class AssociateAccountModel 
    {
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }
}