﻿using System;

namespace Mozu.AubuchonDataAdapter.Web.Models
{
    public class AlternatePersonModel 
    {
      
        public String OrderId { get; set; }
        public String Name { get; set; }
        public String PickupDate { get; set; }
        public String Phone { get; set; }

        public String Notify { get; set; }
    
        public String Ampm { get; set; }
    }
}