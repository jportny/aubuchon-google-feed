﻿namespace Mozu.AubuchonDataAdapter.Web.Models
{
    public class ExternalLookupModel 
    {
      
        public string AubuchonId { get; set; }
    }
}