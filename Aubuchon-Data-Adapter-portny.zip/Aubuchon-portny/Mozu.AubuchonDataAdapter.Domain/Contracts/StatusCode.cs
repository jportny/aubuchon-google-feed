﻿namespace Mozu.AubuchonDataAdapter.Domain.Contracts
{
    public enum StatusCode
    {
        New,
        Active,
        Deleted,
        Inactive
    }
}
