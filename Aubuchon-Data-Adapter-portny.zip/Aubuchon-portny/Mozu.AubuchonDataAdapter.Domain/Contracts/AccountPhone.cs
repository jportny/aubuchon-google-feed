﻿using System;

namespace Mozu.AubuchonDataAdapter.Domain.Contracts
{
    public class AccountPhone
    {
        public string Id { get; set; }
        public int AccountId { get; set; }
        public string Phone { get; set; }
    }
}
