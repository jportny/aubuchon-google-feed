﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Autofac;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.Contracts.CommerceRuntime.Orders;
using Mozu.Api.Contracts.CommerceRuntime.Payments;
using Mozu.Api.Contracts.ProductAdmin;
using Mozu.Api.Contracts.ProductRuntime;
using Mozu.Api.Resources.Commerce;
using Mozu.Api.Resources.Commerce.Catalog.Admin.Attributedefinition.Producttypes;
using Mozu.Api.Resources.Commerce.Catalog.Admin.Products;
using Mozu.Api.Resources.Commerce.Catalog.Storefront;
using Mozu.Api.Resources.Commerce.Customer;
using Mozu.Api.Resources.Commerce.Orders;
using Mozu.Api.Resources.Commerce.Orders.Attributedefinition;
using Mozu.Api.ToolKit.Config;
using Mozu.Api.ToolKit.Readers;
using Mozu.AubuchonDataAdapter.Domain.Handlers;
using Mozu.AubuchonDataAdapter.Domain.Mappers;
using Mozu.AubuchonDataAdapter.Domain.Utility;
using Newtonsoft.Json;
using Category = Mozu.Api.Contracts.CommerceRuntime.Products.Category;
using Exception = System.Exception;
using IEventProcessor = Mozu.Api.ToolKit.Events.IEventProcessor;
using LocationInventory = Mozu.Api.Contracts.ProductAdmin.LocationInventory;
using LocationInventoryResource = Mozu.Api.Resources.Commerce.Catalog.Admin.LocationInventoryResource;
using LocationResource = Mozu.Api.Resources.Commerce.Admin.LocationResource;
using Product = Mozu.Api.Contracts.ProductRuntime.Product;
using ProductProperty = Mozu.Api.Contracts.ProductAdmin.ProductProperty;
using ProductPropertyValue = Mozu.Api.Contracts.ProductAdmin.ProductPropertyValue;
using ProductResource = Mozu.Api.Resources.Commerce.Catalog.Admin.ProductResource;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class OrderTests : BaseTest
    {
        private IApiContext _apiContext;
        private IOrderHandler _orderHandler;
        private IAppSetting _appSetting;
        private IEventHandler _eventHandler;
        private IEventProcessor _eventProcessor;
        private Order _order;
        [TestInitialize]
        public void Init()
        {
            _appSetting = Container.Resolve<IAppSetting>();



            _apiContext = new ApiContext(TenantId, SiteId);
            _orderHandler = new OrderHandler(_appSetting);
            const string orderId = "07ccfdf45621e11820f3b34600003b14";
            //const string orderId = "06fb70b55621e12870bd334500002ac7"; //Payload 15
            //const string orderId = "05e6c9865621e11ea8680fcc00002ac7"; //Payload 2
            //const string orderId = "05eeab425621e11a24eb9c6f00002ac7"; //Payload 13
            //const string orderId = "0614bbe021f663178407825900002ac7"; //Payload 20
            var orderResource = new OrderResource(_apiContext);
            _order = orderResource.GetOrderAsync(orderId).Result;
        }

        [TestMethod]
        public void Should_Get_OrderPayload()
        {
            var orderXml = _order.ToXml();

            Assert.IsNotNull(_order);
        }


        [TestMethod]
        public async Task Should_Process_Order()
        {
            const string entityId = "07e89abc21f663588c29561600003b14";
            try
            {
                //await _orderHandler.UpdateStoreCredits(_apiContext, entityId);

                var order = await (new OrderResource(_apiContext)).GetOrderAsync(entityId);
                var customer =
                    await
                        (new CustomerAccountResource(_apiContext)).GetAccountAsync(
                            Convert.ToInt32(order.CustomerAccountId), "Id, Segments, ExternalId");


                var mozuOrderId = order.Id;

                var splits = _orderHandler.Split(order);
                var orderMapper = new OrderMapper(_appSetting, _apiContext);

                var splitNos = new List<String>();

                foreach (var split in splits)
                {
                    var orderSplit = await orderMapper.ToEdgeOrderExportMessage(split, customer, split.Id, mozuOrderId);
                    var orderXml = orderSplit.ToXml();
                    var filePath = String.Format(@"D:\temp\{0}.xml", split.Id);
                    var xdoc = new XmlDocument();
                    xdoc.LoadXml(orderXml);
                    xdoc.Save(filePath);

                    var sftpHandler = new SftpHandler(_appSetting);
                    //sftpHandler.Push(filePath, "/home/MozuAubuchonSFTP/inbox/JaggedPeak/Mozu/OrderImport/");

                    splitNos.Add(split.Id);
                }


                //Save split numbers to custom attribute
                if (splitNos.Any())
                {
                    var orderAttribResource = new OrderAttributeResource(_apiContext);
                    await orderAttribResource.CreateOrderAttributesAsync(new List<OrderAttribute>()
                    {
                        new OrderAttribute
                        {
                            FullyQualifiedName = AttributeConstants.SplitOrderNumbers,
                            Values = new List<object> {String.Join(",", splitNos.ToArray())}
                        }
                    }, order.Id);
                }
                //Set Event as Processed
                //var aubEvent = evt.ToAubEvent();
                //aubEvent.Status = EventStatus.Processed.ToString();
                //aubEvent.ProcessedDateTime = DateTime.Now;
                //await _eventHandler.UpdateEvent(_apiContext.TenantId, aubEvent);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message, ex);
            }
        }

        [TestMethod]
        public void Should_Map_Mozu_Order_To_Edge_Order_Import_Message()
        {
            var orderMapper = new OrderMapper(_appSetting, _apiContext);
            var customer =
                    (new CustomerAccountResource(_apiContext)).GetAccountAsync(
                        Convert.ToInt32(_order.CustomerAccountId), null).Result;
            //"Id, Segments, ExternalId, TaxId, TaxExempt"

            var orderXml = orderMapper.ToEdgeOrderExportMessage(_order, customer, _order.Id, mozuOrderId: _order.Id).ToXml();
            Assert.IsNotNull(orderXml);
        }

        [TestMethod]
        public async Task Should_Save_Alternate_Person_Pick()
        {
            var model = new AlternatePersonModel();
            model.Ampm = "Am";
            model.Name = "Sumit Thomas";
            model.OrderId = "07c3b5cd5621e10ff0e81deb00003b14";
            model.Phone = "512-913-5555";
            model.PickupDate = "2/21/2016";
           
            var attributeResource = new AttributeResource(_apiContext);
            var pickupAttr = await attributeResource.GetAttributeAsync(AttributeConstants.AlternatePersonPickup);

            var pickupValue = String.Format("{0} , {1}, {2} {3}, SMS {4}", model.Name, model.Phone, model.PickupDate,
                model.Ampm, model.Notify == "1" ? "True" : "False");

            var formatted = String.Format("{0} {1} {2} {3}", model.Name, model.PickupDate, model.Ampm, model.Phone);

            var orderAttribute = new OrderAttribute
            {
                AttributeDefinitionId = pickupAttr.Id,
                FullyQualifiedName = AttributeConstants.AlternatePersonPickup,
                Values = new List<object> { pickupValue }
            };

            var orderAttrResource = new OrderAttributeResource(_apiContext);

            await orderAttrResource.CreateOrderAttributesAsync(new List<OrderAttribute> { orderAttribute }, model.OrderId);
        }

        [TestMethod]
        public void GetCustomer()
        {
            var resource = new CustomerAccountResource(_apiContext);
            var account = resource.GetAccountAsync(10865).Result;
            var attribBirthDate =
                        account.Attributes.FirstOrDefault(a => a.FullyQualifiedName.Equals("tenant~birth-day") && a.Values.Any());
            var day = attribBirthDate != null ? attribBirthDate.Values.First().ToString() : String.Empty;
            Console.WriteLine("Day " + day);
        }

        [TestMethod]
        public void GetAttributeTest()
        {
            var values = new List<object>() { "test" };
            var attributeResource = new AttributeResource(_apiContext);
            var attribute = attributeResource.GetAttributeAsync("reward-auth-ids").Result;

            var resource = new OrderAttributeResource(_apiContext);

            var attributeList = new List<OrderAttribute>();
            var orderAttribute = new OrderAttribute()
            {
                Values = values,
                AttributeDefinitionId = attribute.Id,
                FullyQualifiedName = attribute.AttributeFQN
            };
            attributeList.Add(orderAttribute);

            if (_order.Attributes.All(a => a.AttributeDefinitionId != attribute.Id))
                resource.CreateOrderAttributesAsync(attributeList, _order.Id).Wait();
            else
                resource.UpdateOrderAttributesAsync(attributeList, _order.Id).Wait();
        }


        [TestMethod]
        public void UpdateStoreCreditsForOrder()
        {
            var orderId = "072ea4025621e10e441ffdc200002d99";
            _orderHandler.UpdateStoreCredits(_apiContext, orderId).Wait();
        }

        [TestMethod]
        public void Rewards_Auth_Json_test()
        {
            var authIDs = new Dictionary<string, int>();
            authIDs.Add("434242424234", 123);
            authIDs.Add("5545435534534", 454);
            authIDs.Add("9995435345345", 555);

            var rewards = new List<object>();

            foreach (var auth in authIDs)
            {
                rewards.Add(new { RNo = auth.Key, Auth = auth.Value });
            }

            var json = JsonConvert.SerializeObject(rewards);

            Console.WriteLine(json);
        }

        [TestMethod]
        public void Get_Order_Splits()
        {
            
            var orderMapper = new OrderMapper(_appSetting, _apiContext);

            var customer =
                    (new CustomerAccountResource(_apiContext)).GetAccountAsync(
                        Convert.ToInt32(_order.CustomerAccountId), "Id, Segments, Contacts, ExternalId, TaxExempt, TaxId").Result;

            var splits = _orderHandler.Split(_order);
            foreach (var split in splits)
            {
                //Check rewards only payment. does not match with excel

                var orderXml = orderMapper.ToEdgeOrderExportMessage(split, customer, split.Id).Result.ToXml();
                Console.WriteLine(orderXml);

                var filePath = String.Format(@"c:\temp\temp\{0}.xml", split.Id);
                var xdoc = new XmlDocument();
                xdoc.LoadXml(orderXml);
                xdoc.Save(filePath);
            }
        }

        [TestMethod]
        public void IsShipToStoreItem()
        {
            var productResource = new ProductResource(_apiContext);
            var product = productResource.GetProductAsync("GIFTCARD").Result;
            var isShipToStore = product.Properties.Any(p => p.AttributeFQN.Equals(AttributeConstants.IsShipToStoreItem, StringComparison.InvariantCultureIgnoreCase) && p.Values.Any(v => v.Value.Equals("true")));
            Assert.IsTrue(isShipToStore);
        }

        [TestMethod]
        public void RandonStuff()
        {
            var dt = DateTime.Today;
            var longVal = dt.Ticks;
            Console.WriteLine(longVal);
        }

        [TestMethod]
        public void DeserializeJson()
        {
            const string json = "[{Rewards:\"123\",AuthId:\"abcd\"},{Rewards:\"456\",AuthId:\"efgh\"}]";
            var rewardAuth = new[] { new { Rewards = "", AuthId = "" } };

            var result = JsonConvert.DeserializeAnonymousType(json, rewardAuth);
            foreach (var r in result)
            {
                Console.WriteLine(r.Rewards + " " + r.AuthId);
            }
        }
        [TestMethod]
        public void PushOrderSplits()
        {
            var orderMapper = new OrderMapper(_appSetting, _apiContext);
            var account =
                new CustomerAccountResource(_apiContext).GetAccountAsync(Convert.ToInt32(_order.CustomerAccountId),
                    "Id, Segments, Contacts, ExternalId, TaxExempt, TaxId").Result;

            var splits = _orderHandler.Split(_order);

            foreach (var split in splits)
            {
                var splitOrder = orderMapper.ToEdgeOrderExportMessage(split, account, split.Id).Result;
                var orderXml = splitOrder.ToXml();
                var filePath = String.Format(@"c:\temp\{0}.xml", split.Id);
                var xdoc = new XmlDocument();
                //var xml = orderXml.Substring(orderXml.IndexOf(Environment.NewLine, StringComparison.Ordinal));
                xdoc.LoadXml(orderXml);
                xdoc.Save(filePath);

                var sftpHandler = new SftpHandler(_appSetting);
                sftpHandler.Push(filePath, "/home/MozuAubuchonSFTP/inbox/JaggedPeak/Mozu/OrderImport/");
            }

        }

        [TestMethod]
        public void Should_Split_Order_By_FulfillmentType()
        {
            var original = _order.ToXml();
            var shipToStoreAttrValues =
                _order.Attributes.Where(a => a.FullyQualifiedName == "tenant~ship-to-store")
                    .Select(v => v.Values)
                    .ToList();

            var shipToStoreProducts = String.Empty;

            if (shipToStoreAttrValues.Count != 0)
            {
                shipToStoreProducts = shipToStoreAttrValues[0][0].ToString();
            }

            foreach (var productCode in shipToStoreProducts.Split(','))
            {
                var pcode = productCode.Trim();
                var orderItem = _order.Items.FirstOrDefault(o => o.Product.ProductCode == pcode);
                if (orderItem != null)
                {
                    orderItem.FulfillmentMethod = "ShipToStore";
                }
            }

            var fulfillmentTypeGroup = (from orderItem in _order.Items
                                        group orderItem by orderItem.FulfillmentMethod
                                            into g
                                            select new { FulfillmentType = g.Key, Orders = g.ToList() }).ToList();

            var orderSplits = new List<Order>();

            foreach (var ftype in fulfillmentTypeGroup)
            {
                Console.WriteLine("\n");
                var order = new Order { Items = new List<OrderItem>(), DiscountTotal = 0, DiscountedTotal = 0, Subtotal = 0, ShippingSubTotal = 0, TaxTotal = 0, Total = 0, Payments = new List<Payment>() };

                Console.WriteLine("Fulfillment Type:" + ftype.FulfillmentType);
                foreach (var item in ftype.Orders)
                {
                    //Order level Calculations
                    order.Items.Add(item);
                    order.DiscountTotal += (item.Subtotal - item.TaxableTotal);
                    order.DiscountedTotal += item.TaxableTotal;
                    order.Subtotal += item.Subtotal;
                    order.TaxTotal += item.ItemTaxTotal;
                    order.ShippingSubTotal += item.ShippingTaxTotal;
                    order.Total += item.Total;




                    //End of Calculations

                    Console.WriteLine("--------------------------------------------------------");
                    Console.WriteLine("\tProduct Code         :{0}", item.Product.ProductCode);
                    Console.WriteLine("\tDiscount Total       :{0}", item.DiscountTotal);
                    Console.WriteLine("\tDiscounted Total     :{0}", item.DiscountedTotal);
                    Console.WriteLine("\tExtended Total       :{0}", item.ExtendedTotal);
                    Console.WriteLine("\tFee Total            :{0}", item.FeeTotal);
                    Console.WriteLine("\tHandling Amount      :{0}", item.HandlingAmount);
                    Console.WriteLine("\tItem Tax Total       :{0}", item.ItemTaxTotal);
                    Console.WriteLine("\tSub Total            :{0}", item.Subtotal);
                    Console.WriteLine("\tShipping Tax Total   :{0}", item.ShippingTaxTotal);
                    Console.WriteLine("\tShipping Total       :{0}", item.ShippingTotal);
                    Console.WriteLine("\tTaxable Total        :{0}", item.TaxableTotal);
                    Console.WriteLine("\tTotal                :{0}", item.Total);
                    Console.WriteLine("\tUnit Price - List amount      :{0}", item.UnitPrice.ListAmount);

                }

                //Additional Order Level Calculations/Assignments
                order.ShippingSubTotal = 0;

                if (ftype.FulfillmentType == "Ship")
                {
                    decimal? impact = 0;
                    if (_order.ShippingDiscounts.Count > 0)
                    {
                        impact = _order.ShippingDiscounts.First().Discount.Impact;
                    }
                    order.DiscountTotal += impact;

                    order.DiscountedTotal -= impact;
                    order.ShippingSubTotal += _order.ShippingSubTotal;
                }
                orderSplits.Add(order);

                Console.WriteLine(">>>>>>>>>>>>>>>>>>Order Totals<<<<<<<<<<<<<<<<<<<<<");
                Console.WriteLine("Discount Total       :{0}", order.DiscountTotal);
                Console.WriteLine("Discounted Total     :{0}", order.DiscountedTotal);
                Console.WriteLine("Sub Total            :{0}", order.Subtotal);
                Console.WriteLine("Tax Total            :{0}", order.TaxTotal);
                Console.WriteLine("Shipping Sub Total   :{0}", order.ShippingSubTotal);
                Console.WriteLine("Total                :{0}", order.Total);
            }

            if (orderSplits.Any())
            {

                var storeCredits = new Stack<Payment>(_order.Payments.Where(p => p.PaymentType == "StoreCredit").OrderByDescending(o => o.AmountRequested).ToList());
                var credits = _order.Payments.Where(p => p.PaymentType == "CreditCard").OrderBy(o => o.AmountRequested).ToList();
                var paypal = _order.Payments.Where(p => p.PaymentType == "Paypal").OrderByDescending(o => o.AmountRequested).ToList();
                //storeCreditAmount = storeCredits.Sum(p => p.AmountRequested);
                //creditAmount = credits.Sum(p => p.AmountRequested);
                //paypalAmount = paypal.Sum(p => p.AmountRequested);

                //storeCreditApplied = storeCreditAmount;
                //creditAmountApplied = creditAmount;
                //paypalAmountApplied = paypalAmount;
                Console.WriteLine("##############################Payments to Assign#################################");



                foreach (var sc in storeCredits)
                {
                    Console.WriteLine("Store Credit {0}", sc.AmountRequested);
                }
                foreach (var c in credits)
                {
                    Console.WriteLine("Credit Card Amt {0}", c.AmountRequested);
                }

                Console.WriteLine("##############################Split Orders#################################");

                //Apply Store Credits
                foreach (var order in orderSplits.OrderBy(o => o.Total))
                {
                    var toCollect = order.Total;


                    while (toCollect > 0 && storeCredits.Any())
                    {
                        var sc = storeCredits.Pop();

                        if (toCollect < sc.AmountRequested)
                        {
                            var remainder = ClonePayment(sc);
                            remainder.AmountRequested = (decimal)(sc.AmountRequested - toCollect);

                            if (toCollect != null)
                            {
                                sc.AmountRequested = (decimal)toCollect;
                                order.Payments.Add(sc);

                                storeCredits.Push(remainder);
                            }
                            toCollect -= sc.AmountRequested;
                            continue;
                        }

                        if (!(toCollect >= sc.AmountRequested)) continue;
                        toCollect -= sc.AmountRequested;
                        order.Payments.Add(sc);
                    }

                }

                var maxTotal = orderSplits.Max(o => o.Total);
                var largestOrder = orderSplits.FirstOrDefault(o => o.Total == maxTotal);
                if (largestOrder != null)
                {
                    //Apply CC payments
                    var ccPayment = credits.FirstOrDefault(o => o.AmountRequested == credits.Max(p => p.AmountRequested));

                    if (ccPayment != null)
                    {
                        largestOrder.Payments.Add(ccPayment);
                    }

                    //Apply Paypal payments
                    var ppPayment = paypal.FirstOrDefault(o => o.AmountRequested == paypal.Max(p => p.AmountRequested));
                    if (ppPayment != null)
                    {
                        largestOrder.Payments.Add(ppPayment);
                    }
                    //var toCollect = largestOrder.Total;

                    //while (toCollect > 0 && credits.Any())
                    //{
                    //    var credit = credits.Pop();
                    //    if (toCollect < credit.AmountRequested)
                    //    {
                    //        var remainder = ClonePayment(credit);
                    //        remainder.AmountRequested = (decimal)(credit.AmountRequested - toCollect);
                    //        if (toCollect != null)
                    //        {
                    //            credit.AmountRequested = (decimal)toCollect;
                    //            largestOrder.Payments.AddEvent(credit);

                    //            storeCredits.Push(remainder);
                    //        }
                    //        toCollect -= credit.AmountRequested;
                    //    }

                    //    if (!(toCollect >= credit.AmountRequested)) continue;
                    //    toCollect -= credit.AmountRequested;
                    //    largestOrder.Payments.AddEvent(credit);
                    //}
                }

                //Apply Paypal
                //foreach (var order in orderSplits.OrderBy(o => o.Total))
                //{
                //    var toCollect = order.Total;
                //    while (toCollect > 0 && paypal.Any())
                //    {
                //        var pp = paypal.Pop();

                //        if (toCollect < pp.AmountRequested)
                //        {
                //            var remainder = ClonePayment(pp);
                //            remainder.AmountRequested = (decimal)(pp.AmountRequested - toCollect);

                //            if (toCollect != null)
                //            {
                //                pp.AmountRequested = (decimal)toCollect;
                //                order.Payments.AddEvent(pp);

                //                paypal.Push(remainder);
                //            }
                //            toCollect -= pp.AmountRequested;
                //            continue;
                //        }

                //        if (!(toCollect >= pp.AmountRequested)) continue;
                //        toCollect -= pp.AmountRequested;
                //        order.Payments.AddEvent(pp);
                //    }
                //}


                foreach (var order in orderSplits.OrderBy(o => o.Total))
                {
                    Console.WriteLine("Order Total :{0}", order.Total);
                    Console.WriteLine("#############################Payments Assigned##################################");

                    var split = order.ToXml();
                    foreach (var payment in order.Payments)
                    {
                        if (payment.PaymentType == "StoreCredit")
                        {
                            Console.WriteLine("Store Credit :{0}", payment.BillingInfo.StoreCreditCode);
                            Console.WriteLine("Store Credit :{0}", payment.AmountRequested);
                        }
                        else if (payment.PaymentType == "CreditCard")
                        {
                            Console.WriteLine("Credit Card :{0}", payment.BillingInfo.Card.PaymentOrCardType);
                            Console.WriteLine("Amount :{0}", payment.AmountRequested);
                        }
                    }

                    Console.WriteLine("----------------------------------------------");
                }
            }
        }

        [TestMethod]
        public async Task Get_Order_ByRef()
        {




            var status = await _orderHandler.GetOrderStatus(_apiContext, "06baa8e25621e10c0c5c88a400002ac7");
            Console.WriteLine(status);

            //    var apiContext = new ApiContext(10951);
            //    const string orderId = "06baa8e25621e10c0c5c88a400002ac7"; //order number 99
            //    var orderResource = new OrderResource(apiContext);
            //    var order = await orderResource.GetOrderAsync(orderId);



            ////    var client = new OrderHeaderServiceClient();

            ////client.ChannelFactory.Credentials.UserName.UserName = "Mozu";
            ////client.ChannelFactory.Credentials.UserName.Password = "Mozu12345";

            //    var splitOrders = order.Attributes.Any(a => a.FullyQualifiedName == "tenant~splitordernumbers")
            //        ? Convert.ToString(
            //            order.Attributes.First(a => a.FullyQualifiedName == "tenant~splitordernumbers")
            //                .Values.FirstOrDefault())
            //        : String.Empty;

            //    if (String.IsNullOrEmpty(splitOrders)) return;
            //    var splits = splitOrders.Split(',');
            //    foreach (var item in splits)
            //    {
            //        //var status = await _orderHandler.GetOrderStatus(item);
            //        var status = _orderHandler.GetOrderStatus(item).Result;
            //    }



            //string clientReference = _order.OrderNumber + "_2";
            //var test = client.getOrderHeaderByRefAsync(16425, clientReference).ConfigureAwait(false);
        }

        [TestMethod]
        public void Get_Order_Status()
        {
            var apiContext = new ApiContext(TenantId, SiteId);
            var orderId = "076fa8335621e121f414cfe100002d99";
            try
            {
                var orderStatus = _orderHandler.GetOrderStatus(apiContext, orderId).Result;

            }
            catch (System.Exception exception)
            {
                var msg = exception.Message;
            }
        }

        [TestMethod]
        public async Task Outofstock_Inventory_Test()
        {
            var productCode = "100002";
            const string dcCode = "991";
            var locationInventoryResource =
                new Api.Resources.Commerce.Catalog.Admin.Products.LocationInventoryResource(_apiContext);

            var notInDc = false;
            var productAttribResource = new ProductPropertyResource(_apiContext);

            var filter = String.Format("StockAvailable eq 0 and UpdateDate gt '{0}'",
                DateTime.Now.AddMinutes(-5).ToString("u"));

            
            var locations = new List<LocationInventory>();
            var locationInventoryReader = new ProductLocationInventoryReader
            {
                ProductCode = productCode,
                Context = _apiContext,
                Filter = filter,
                PageSize = 200,
                ResponseFields = "Items(LocationCode)"
            };

            while (await locationInventoryReader.ReadAsync())
            {
                locations.AddRange(locationInventoryReader.Items);
            }

            //var locations =
            //    await
            //        locationInventoryResource.GetLocationInventoriesAsync(productCode, filter: filter, responseFields: "Items(LocationCode)", pageSize: 200);


            var locationAttrib = await productAttribResource.GetPropertyAsync(productCode, AttributeConstants.LocationCode, "AttributeFQN,Values");
            if (locationAttrib.AttributeFQN != null)
            {
                var hasChanges = false;
                if (locationAttrib.Values == null)
                {
                    notInDc = true;
                }
                else
                {
                    foreach (
                        var item in
                            locations.Select(
                                location =>
                                    locationAttrib.Values.Where(p => p.Value.Equals(location.LocationCode)).ToList())
                                .Where(item => item.Any()))
                    {
                        if (item.Any(a => a.Value != null && Convert.ToString(a.Value).Equals(dcCode)))
                        {
                            notInDc = true;
                        }
                        locationAttrib.Values.Remove(item.First());
                        hasChanges = true;
                    }

                    if (hasChanges)
                        await
                            productAttribResource.UpdatePropertyAsync(locationAttrib, productCode,
                                AttributeConstants.LocationCode);
                }
            }

            if (notInDc)
            {
                var indcAttribute =
                    await
                        productAttribResource.GetPropertyAsync(productCode, AttributeConstants.InDc,
                            "AttributeFQN,Values");
                var indc = new ProductProperty
                {
                    AttributeFQN = AttributeConstants.InDc,
                    Values =
                        new List<Api.Contracts.ProductAdmin.ProductPropertyValue>
                            {
                                new Api.Contracts.ProductAdmin.ProductPropertyValue {Value = "false"}
                            }
                };
                if (indcAttribute == null)
                {

                    await productAttribResource.AddPropertyAsync(indc, productCode);
                }
                else
                {
                    await productAttribResource.UpdatePropertyAsync(indc, productCode, AttributeConstants.InDc);
                }
            }

            /*


                var locationAttrib = await productAttribResource.GetPropertyAsync(productCode, AttributeConstants.LocationCode, "AttributeFQN,Values");
                var locationAttribClone = new ProductProperty
                {
                    AttributeFQN = locationAttrib.AttributeFQN,
                    Values = locationAttrib.Values
                };
            if (locationAttrib.AttributeFQN != null)
            {
                if (locationAttrib.Values != null)
                {
                    foreach (var item in locationAttrib.Values)
                    {
                        var
                            location =
                                await
                                    locationInventoryResource.GetLocationInventoryAsync(Convert.ToString(item.Value),
                                        productCode, "LocationCode,StockAvailable");
                        if (location == null || !(location.StockAvailable <= 0)) continue;
                        locationAttribClone.Values.Remove(item);

                        if (location.LocationCode.Equals("991"))
                        {
                            notInDc = true;

                        }

                        hasChanges = true;
                    }
                    if (hasChanges)
                        await
                            productAttribResource.UpdatePropertyAsync(locationAttribClone, productCode,
                                AttributeConstants.LocationCode);
                }
                else
                {
                    notInDc = true;
                }
                if (notInDc)
                {
                    var indcAttribute =
                        await
                            productAttribResource.GetPropertyAsync(productCode, AttributeConstants.InDc,
                                "AttributeFQN,Values");
                    var indc = new ProductProperty
                    {
                        AttributeFQN = AttributeConstants.InDc,
                        Values =
                            new List<Api.Contracts.ProductAdmin.ProductPropertyValue>
                            {
                                new Api.Contracts.ProductAdmin.ProductPropertyValue {Value = "false"}
                            }
                    };
                    if (indcAttribute == null)
                    {

                        await productAttribResource.AddPropertyAsync(indc, productCode);
                    }
                    else
                    {
                        await productAttribResource.UpdatePropertyAsync(indc, productCode, AttributeConstants.InDc);
                    }
                }
            }
            //        await productAttribResource.UpdatePropertyAsync(locationAttrib, productCode, AttributeConstants.LocationCode);
            //}*/
        }

        [TestMethod]
        public async Task Instock_Inventory_test()
        {
            try
            {
                var productCode = "604140";
                const string dcCode = "991";
                var locationInventoryResource =
                    new Api.Resources.Commerce.Catalog.Admin.Products.LocationInventoryResource(_apiContext);



                var productAttribResource = new ProductPropertyResource(_apiContext);
                var filter = String.Format("StockOnHand gt 0 and UpdateDate gt '{0}'",
                    DateTime.Now.AddMinutes(-5).ToString("u"));
                var locations =
                    await
                        locationInventoryResource.GetLocationInventoriesAsync(productCode, filter: filter, pageSize: 200,
                            responseFields: "Items(LocationCode),AuditInfo");



                //Add any new location to locationcode attribute

                var attributeResource = new Api.Resources.Commerce.Catalog.Admin.Attributedefinition.AttributeResource(_apiContext);
                var locationCodeAttrib = await attributeResource.GetAttributeAsync(AttributeConstants.LocationCode);
                var hasNewLocationCode = false;
                foreach (var loc in locations.Items)
                {
                    if (locationCodeAttrib.VocabularyValues.Any(
                        a => a.Value != null && Convert.ToString(a.Value).Equals(loc.LocationCode))) continue;
                    locationCodeAttrib.VocabularyValues.Add(new AttributeVocabularyValue { Value = loc.LocationCode });
                    hasNewLocationCode = true;
                }

                if (hasNewLocationCode)
                    await attributeResource.UpdateAttributeAsync(locationCodeAttrib, AttributeConstants.LocationCode);

                const int baseProductTypeId = 1;

                //Add attribute to product type
                var hasNewProductTypeValue = false;

                var productTypePropertyResource = new ProductTypePropertyResource(_apiContext);

                var lcAttribute = await productTypePropertyResource.GetPropertyAsync(baseProductTypeId, AttributeConstants.LocationCode);


                foreach (
                    var loc in
                        locations.Items)
                {
                    if (lcAttribute.VocabularyValues.Any(v => v.Value != null && Convert.ToString(v.Value).Equals(loc.LocationCode))) continue;

                    var val = new AttributeVocabularyValueInProductType
                    {
                        Value = loc.LocationCode,
                        VocabularyValueDetail = new AttributeVocabularyValue() { Value = loc.LocationCode, Content = new AttributeVocabularyValueLocalizedContent() { StringValue = loc.LocationCode } }
                    };

                    lcAttribute.VocabularyValues.Add(val);
                    hasNewProductTypeValue = true;
                }

                if (hasNewProductTypeValue)
                    await
                        productTypePropertyResource.UpdatePropertyAsync(lcAttribute, baseProductTypeId, AttributeConstants.LocationCode);




                //Update Product Location Code attribute
                var locationAttrib = await productAttribResource.GetPropertyAsync(productCode, AttributeConstants.LocationCode);

                if (locationAttrib == null)
                {
                    foreach (var attr in locations.Items.Select(location => new ProductProperty
                    {
                        AttributeFQN = locationCodeAttrib.AttributeFQN,
                        Values =
                            new List<Api.Contracts.ProductAdmin.ProductPropertyValue>
                            {
                                new Api.Contracts.ProductAdmin.ProductPropertyValue {Value = location.LocationCode}
                            }
                    }))
                    {
                        await productAttribResource.AddPropertyAsync(attr, productCode);
                    }
                }
                else
                {
                    var hasChanges = false;
                    foreach (var location in locations.Items)
                    {
                        if (locationAttrib.Values != null && locationAttrib.Values.Any(a => a.Value.Equals(location.LocationCode))) continue;
                        if (locationAttrib.Values == null)
                        {
                            locationAttrib.Values = new List<Api.Contracts.ProductAdmin.ProductPropertyValue>();
                        }
                        locationAttrib.Values.Add(new Api.Contracts.ProductAdmin.ProductPropertyValue { Value = location.LocationCode });
                        hasChanges = true;
                    }
                    if (hasChanges)
                        await productAttribResource.UpdatePropertyAsync(locationAttrib, productCode, AttributeConstants.LocationCode);
                }


                //Check InDc Flag if DC code 991 is selected in LocationCode attribute.
                if (locationAttrib != null && locationAttrib.Values.Any(v => v.Value.Equals(dcCode)))
                {
                    var indcAttribute =
                        await
                            productAttribResource.GetPropertyAsync(productCode, AttributeConstants.InDc,
                                "AttributeFQN,Values");
                    var indc = new ProductProperty
                    {
                        AttributeFQN = AttributeConstants.InDc,
                        Values =
                            new List<Api.Contracts.ProductAdmin.ProductPropertyValue>
                            {
                                new Api.Contracts.ProductAdmin.ProductPropertyValue {Value = 1}
                            }
                    };
                    if (indcAttribute == null)
                    {

                        await productAttribResource.AddPropertyAsync(indc, productCode);
                    }
                    else
                    {
                        await productAttribResource.UpdatePropertyAsync(indc, productCode, AttributeConstants.InDc);
                    }
                }
            }
            catch (Exception ex)
            {
                var msg = ex.Message;
            }
        }

        [TestMethod]
        public async Task Outofstock_Inventory_test()
        {
            try
            {

                const string productCode = "100002";

                var productAttribResource = new ProductPropertyResource(_apiContext);

                var filter = String.Format("StockAvailable le 0 and UpdateDate gt '{0}'",
                    DateTime.Now.AddMinutes(-5).ToString("u"));
                var locations = await GetProductLocations(_apiContext, productCode, filter);

                var locationAttrib = await productAttribResource.GetPropertyAsync(productCode, AttributeConstants.LocationCode, "AttributeFQN,Values");
                if (locationAttrib.AttributeFQN != null)
                {
                    //locationAttrib.AttributeFQN = locationAttrib.AttributeFQN.ToLower();
                    var hasChanges = false;

                    foreach (
                        var item in
                            locations.Select(
                                location =>
                                    locationAttrib.Values.Where(p => p != null && Convert.ToString(p.Value).Equals(location.LocationCode, StringComparison.InvariantCultureIgnoreCase))).ToList()
                                .Where(item => item.Any()))
                    {
                        locationAttrib.Values.Remove(item.First());
                        hasChanges = true;
                    }

                    if (hasChanges)
                        await
                            productAttribResource.UpdatePropertyAsync(locationAttrib, productCode,
                                locationAttrib.AttributeFQN);
                }

                //await ExportProductInventoryAsync(apiContext, eventPayLoad);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        protected async Task<IList<LocationInventory>> GetProductLocations(IApiContext apiContext, string productCode, string filter = null)
        {
            var locations = new List<LocationInventory>();

            var inventoryReader = new ProductLocationInventoryReader
            {
                Context = apiContext,
                ProductCode = productCode,
                PageSize = 200,
                ResponseFields = "Items(LocationCode),AuditInfo",
                Filter = filter
            };
            while (await inventoryReader.ReadAsync())
            {
                locations.AddRange(inventoryReader.Items);
            }
            return locations;
        }

        [TestMethod]
        public async Task Populate_InDcStoreAttribute()
        {
            var dcCode = "991";
            var productAttribResource = new ProductPropertyResource(_apiContext);
            var locationInventoryResource =
                 new Api.Resources.Commerce.Catalog.Admin.Products.LocationInventoryResource(_apiContext);
            var reader = new LocationInventoryReader { Context = _apiContext, PageSize = 200, LocationCode = dcCode };
            var attributeResource = new Api.Resources.Commerce.Catalog.Admin.Attributedefinition.AttributeResource(_apiContext);
            var locationCodeAttrib = await attributeResource.GetAttributeAsync(AttributeConstants.LocationCode);

            const int baseProductTypeId = 1;

            //Add attribute to product type
            var hasNewProductTypeValue = false;

            var productTypePropertyResource = new ProductTypePropertyResource(_apiContext);

            var lcAttribute = await productTypePropertyResource.GetPropertyAsync(baseProductTypeId, AttributeConstants.LocationCode);




            while (await reader.ReadAsync())
            {
                foreach (var item in reader.Items)
                {
                    if (item.StockAvailable > 0)
                    {
                        //Update Product Location Code attribute
                        var locationAttrib =
                            await
                                productAttribResource.GetPropertyAsync(item.ProductCode, AttributeConstants.LocationCode);
                        var prop = new ProductProperty()
                        {
                            AttributeFQN = AttributeConstants.LocationCode,
                            Values = new List<ProductPropertyValue>() {new ProductPropertyValue() {Value = dcCode}}
                        };
                        if (locationAttrib == null)
                        {
                            {
                                await productAttribResource.AddPropertyAsync(prop, item.ProductCode);
                            }
                        }
                        else
                        {

                            await
                                productAttribResource.UpdatePropertyAsync(prop, item.ProductCode,
                                    AttributeConstants.LocationCode);
                        }


                        //Check InDc Flag if DC code 991 is selected in LocationCode attribute.
                        //if (locationAttrib != null && locationAttrib.Values.Any(v => v.Value.Equals(dcCode)))
                        //{
                            var indcAttribute =
                                await
                                    productAttribResource.GetPropertyAsync(item.ProductCode, AttributeConstants.InDc,
                                        "AttributeFQN,Values");
                            var indc = new ProductProperty
                            {
                                AttributeFQN = AttributeConstants.InDc,
                                Values =
                                    new List<Api.Contracts.ProductAdmin.ProductPropertyValue>
                            {
                                new Api.Contracts.ProductAdmin.ProductPropertyValue {Value = 1}
                            }
                            };
                            if (indcAttribute == null)
                            {

                                await productAttribResource.AddPropertyAsync(indc, item.ProductCode);
                            }
                            else
                            {
                                await productAttribResource.UpdatePropertyAsync(indc, item.ProductCode, AttributeConstants.InDc);
                            }
                        //}
                    }
                }
            }
        }

        private Payment ClonePayment(Payment payment)
        {
            var clone = new Payment
            {
                AmountCollected = payment.AmountCollected,
                AmountCredited = payment.AmountCredited,
                AmountRequested = payment.AmountRequested,
                BillingInfo = payment.BillingInfo,
                PaymentType = payment.PaymentType,
                OrderId = payment.OrderId,
                PaymentServiceTransactionId = payment.PaymentServiceTransactionId
            };
            return clone;
        }

        private IList<Order> SplitOrderByFulfillmentType(Order parentOrder)
        {
            var shipToStoreAttrValues =
               parentOrder.Attributes.Where(a => a.FullyQualifiedName == "tenant~ship-to-store")
                   .Select(v => v.Values)
                   .ToList();

            var shipToStoreProducts = String.Empty;

            if (shipToStoreAttrValues.Count != 0)
            {
                shipToStoreProducts = shipToStoreAttrValues[0][0].ToString();
            }

            foreach (var productCode in shipToStoreProducts.Split(','))
            {
                var pcode = productCode.Trim();
                var orderItem = _order.Items.FirstOrDefault(o => o.Product.ProductCode == pcode);
                if (orderItem != null)
                {
                    orderItem.FulfillmentMethod = "ShipToStore";
                }
            }

            var fulfillmentTypeGroup = (from orderItem in _order.Items
                                        group orderItem by orderItem.FulfillmentMethod
                                            into g
                                            select new { FulfillmentType = g.Key, Orders = g.ToList() }).ToList();

            var orderSplits = new List<Order>();

            foreach (var ftype in fulfillmentTypeGroup)
            {
                var order = new Order { Items = new List<OrderItem>(), DiscountTotal = 0, DiscountedTotal = 0, Subtotal = 0, ShippingSubTotal = 0, TaxTotal = 0, Total = 0 };

                foreach (var item in ftype.Orders)
                {
                    //Order level Calculations
                    order.Items.Add(item);

                    order.DiscountTotal += (item.Subtotal - item.TaxableTotal);
                    order.DiscountedTotal += item.TaxableTotal;
                    order.Subtotal += item.Subtotal;
                    order.TaxTotal += item.ItemTaxTotal;
                    order.ShippingSubTotal += item.ShippingTaxTotal;
                    order.Total += item.Total;

                    orderSplits.Add(order);
                    //End of Calculations

                }

                //Additional Order Level Calculations/Assignments
                order.ShippingSubTotal = 0;

                if (ftype.FulfillmentType != "Ship") continue;
                decimal? impact = 0;
                if (_order.ShippingDiscounts.Count > 0)
                {
                    impact = _order.ShippingDiscounts.First().Discount.Impact;
                }
                order.DiscountTotal += impact;

                order.DiscountedTotal -= impact;
                order.ShippingSubTotal += _order.ShippingSubTotal;
            }
            return orderSplits;
        }

        [TestMethod]
        public void GetInventoryByLocation()
        {
            var locationResource = new LocationInventoryResource(_apiContext);
            var sfSearchResource = new ProductSearchResultResource(_apiContext);
            var sf = new Mozu.Api.Resources.Commerce.Catalog.Storefront.ProductResource(_apiContext);

            var adminSearch = new Mozu.Api.Resources.Commerce.Catalog.Admin.SearchResource(_apiContext);
            var pageCount = 0;
            var filterdProducts = 0;
            var fetchedAll = false;
            var result = new List<Product>();

            var search = String.Empty;

            if (String.IsNullOrEmpty(search))
            {

                while (filterdProducts < 25)
                {
                    //responseFields: "Items(ProductCode)"
                    //var productsAtLocation =
                    //    locationResource.GetLocationInventoriesAsync("080", pageCount, 25, filter: "StockAvailable gt 0").Result;

                    //var filter = new StringBuilder();
                    //filter.Append("(");
                    //for (var i = 0; i < productsAtLocation.Items.Count; i++)
                    //{
                    //    filter.AppendFormat("(ProductCode eq '{0}')", productsAtLocation.Items[i].ProductCode);
                    //    if (i != productsAtLocation.Items.Count - 1)
                    //    {
                    //        filter.Append(" Or ");
                    //    }
                    //}
                    //filter.Append(")");



                    var products =
                        sfSearchResource.SearchAsync(null, null, pageSize: 175, startIndex: pageCount)
                            .Result;

                    var locationQuery = new LocationInventoryQuery
                    {
                        LocationCodes = new List<string> { "080" },
                        ProductCodes = products.Items.Select(p => p.ProductCode).Distinct().ToList()
                    };
                    var inlocationProds = sf.GetProductInventoriesAsync(locationQuery).Result;
                    foreach (var prod in from item in inlocationProds.Items
                                         where result.All(p => p.ProductCode != item.ProductCode)
                                         select products.Items.FirstOrDefault(p => p.ProductCode == item.ProductCode))
                    {
                        result.Add(prod);
                        filterdProducts++;
                    }

                    pageCount++;

                }
            }
            else
            {
                while (filterdProducts < 25 && !fetchedAll)
                {

                    var products =
                       sfSearchResource.SearchAsync(search, null, pageSize: 25, startIndex: pageCount)
                           .Result;

                    var filter = new StringBuilder();
                    filter.Append("(");
                    for (var i = 0; i < products.Items.Count; i++)
                    {
                        filter.AppendFormat("(ProductCode eq '{0}')", products.Items[i].ProductCode);
                        Debug.WriteLine(i + " " + products.Items.Count);
                        if (i != products.Items.Count - 1)
                        {
                            filter.Append(" Or ");
                        }
                    }
                    filter.Append(")");



                    var locationFilter = String.Format("StockAvailable gt 0 and {0}", filter);

                    var productsAtLocation =
                        locationResource.GetLocationInventoriesAsync("080", pageCount, 25, filter: locationFilter,
                            responseFields: "Items(ProductCode)").Result;



                    pageCount++;
                    result.AddRange(products.Items);

                    filterdProducts += products.Items.Count;

                    if (products.TotalCount == 0) fetchedAll = true;
                }
            }


            Assert.IsNotNull(result);

            //var ofsProducts = new List<LocationInventory>();

            //var locationReader = new LocationInventoryReader
            //{
            //    Context = _apiContext,
            //    LocationCode = "080",
            //    Filter = "StockAvailable le 0",
            //    ResponseFields = "Items(ProductCode)",
            //    PageSize = 200
            //};

            //while (locationReader.ReadAsync().Result)
            //{
            //    ofsProducts.AddRange(locationReader.Items);
            //}

            //var ofs = ofsProducts.Select(item => item.ProductCode).ToList();


            //var inventoryResource = new LocationInventoryResource(_apiContext);




            ////var stockFilter = String.Format("StockAvailable le 0");
            ////const string query = "cordless";
            ////var inventory = locationResource.GetLocationInventoriesAsync("080", null,null,null,stockFilter).Result;
            ////var prodList = new StringBuilder();
            ////prodList.Append("(");
            ////for (var i = 0; i < ofsProducts.Count; i++)
            ////{
            ////    prodList.AppendFormat("(ProductCode ne '{0}')", ofsProducts[i].ProductCode);
            ////    Debug.WriteLine(i + " " + ofsProducts.Count);
            ////    if (i != ofsProducts.Count - 1)
            ////    {
            ////        prodList.Append(" Or ");
            ////    }
            ////}
            ////prodList.Append(")");

            ////var searchFilter = prodList.ToString();




            var skip = new List<string>();

            var itemsAdded = 0;
            var maxPageCount = 0;
            while (itemsAdded < 25 && !fetchedAll)
            {
                var products = sfSearchResource.SearchAsync(null, null, pageSize: 200, startIndex: pageCount).Result;
                if (maxPageCount == 0) maxPageCount = products.PageCount;
                var items = products.Items.Where(p => p.InventoryInfo.OnlineStockAvailable > 0).Select(p => p.ProductCode).Distinct().ToList();
                var locationQuery = new LocationInventoryQuery
                {
                    LocationCodes = new List<string> { "080" },
                    ProductCodes = items
                };
                var inlocationProds = sf.GetProductInventoriesAsync(locationQuery).Result;
                foreach (var prod in from item in inlocationProds.Items
                                     where result.All(p => p.ProductCode != item.ProductCode)
                                     select products.Items.FirstOrDefault(p => p.ProductCode == item.ProductCode))
                {
                    result.Add(prod);
                    itemsAdded++;
                }
                pageCount++;
                if (pageCount >= maxPageCount) fetchedAll = true;
            }



            foreach (var item in result)
            {
                Debug.WriteLine(item.ProductCode);
            }



            Assert.IsNotNull(result);
        }



    }


    public class AlternatePersonModel
    {

        public String OrderId { get; set; }
        public String Name { get; set; }
        public String PickupDate { get; set; }
        public String Phone { get; set; }

        public String Notify { get; set; }

        public String Ampm { get; set; }
    }

}
