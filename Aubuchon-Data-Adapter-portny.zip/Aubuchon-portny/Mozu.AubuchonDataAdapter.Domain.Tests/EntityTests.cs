﻿using System;
using System.Collections.Generic;
using System.Linq;
using Autofac;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.Contracts.Event;
using Mozu.Api.Resources.Platform;
using Mozu.Api.Resources.Platform.Entitylists;
using Mozu.Api.ToolKit.Config;
using Mozu.Api.ToolKit.Handlers;
using Mozu.Api.ToolKit.Readers;
using Mozu.AubuchonDataAdapter.Domain.Contracts;
using Mozu.AubuchonDataAdapter.Domain.Events;
using Mozu.AubuchonDataAdapter.Domain.Handlers;
using Mozu.AubuchonDataAdapter.Domain.Jobs;
using Mozu.Integration.Scheduler;
using EventHandler = Mozu.AubuchonDataAdapter.Domain.Handlers.EventHandler;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class EntityTests : BaseTest
    {
        private IAppSetting _appSetting;
        IApiContext _apiContext;
        private IEventHandler _eventHandler;
        private IEntityHandler _entityHandler;
        private IEventProcessor _eventProcessor;
        private ILogHandler _logHandler;
        private IAccountPhoneHandler _accountPhoneHandler;

        private string _listFullName;

        [TestInitialize]
        public void Init()
        {
            _appSetting = Container.Resolve<IAppSetting>();
            _entityHandler = Container.Resolve<IEntityHandler>();
            _eventProcessor = Container.Resolve<IEventProcessor>();
            _logHandler = Container.Resolve<ILogHandler>();
            _eventHandler = new EventHandler(_appSetting, _eventProcessor);
            _accountPhoneHandler = Container.Resolve<IAccountPhoneHandler>();
            _apiContext = new ApiContext(TenantId, SiteId);

            _listFullName = "AubEvent@a33b3df";
        }

        [TestMethod]
        public void InstallSchema()
        {
            var handler = new EntityListResource(_apiContext);
            var lists = handler.GetEntityListsAsync().Result;

            _eventHandler.InstallSchema(_apiContext.TenantId).Wait();
        }


        [TestMethod]
        public void Entity()
        {
            var apicontext = new ApiContext(15124,21392);
            var fullname = "AccountPhones@a33b3df";
            var filter =  String.Format("Id sw '{0}'", 1001);
            var entityResource = new EntityResource(apicontext);
            var result = entityResource.GetEntitiesAsync(fullname,200,null, null).Result.Items;

            
            foreach (var r in result)
            {
                Console.WriteLine(r);
            }
        }

        [TestMethod]
        public void Should_Get_Log_List()
        {
            var log = _logHandler.List(_apiContext.TenantId, 200, null, null).Result;

            foreach (var l in log)
            {

                Console.WriteLine(String.Format("{0} / {1} / {2} / {3} / {4}", l.EntityId, l.Message, l.LogType, l.LoggerName, l.CreatedOn));

            }
        }


        [TestMethod]
        public void Should_Get_Queued_Events()
        {
            string pending = EventStatus.Pending.ToString();
            var filter = String.Format("Status eq '{0}'", EventStatus.Pending);

            var events = _eventHandler.GetEvents(_apiContext.TenantId, filter).Result;

            foreach (var evt in events)
            {

                Console.WriteLine(evt.ToString());
                
            }
        }

        [TestMethod]
        public void Get_Mozu_Event()
        {
            var lastRunTime = DateTime.Now.AddHours(-1);
            var      filter = String.Format("createDate gt '{0}'", lastRunTime.ToString("u"));

            var eventReader = new EventReader { Context = _apiContext, Filter = filter, PageSize = 200 };
            var eventList = new List<Event>();
            while (eventReader.ReadAsync().Result)
            {
                eventList.AddRange(eventReader.Items);
            }

            if (eventList.Any())
            {

                var concise = from record in eventList
                    group record by new {record.EntityId, record.Topic}
                    into g
                    let recent = (
                        from groupedItem in g
                        orderby groupedItem.AuditInfo.UpdateDate descending
                        select groupedItem
                        ).First()
                    select recent;


                foreach (var evt in concise)
                {
                    Console.WriteLine(evt.EventId + " " + evt.EntityId + " " + evt.Topic + " " + evt.AuditInfo.CreateDate);
                }
            }
        }

        [TestMethod]
        public void Should_Get_Phone_List()
        {

            var phones = _accountPhoneHandler.GetAccountsWithPhone(_apiContext.TenantId, "4134985436").Result;

            foreach (var ph in phones)
            {

                Console.WriteLine(ph.Phone);

            }
        }

        [TestMethod]
        public void AddJobs()
        {
            var jobScheduler = Container.Resolve<IJobScheduler>();
            //testJob
            int tenantId = _apiContext.TenantId;
            tenantId = 11673;
            jobScheduler.RemoveJob(tenantId, "ImportEdgeMemberJob");
            jobScheduler.RemoveJob(tenantId, "ProcessEventQueueJob");
            jobScheduler.RemoveJob(tenantId, "ProcessMissedEventsJob");


            jobScheduler.RemoveJob(tenantId, "DownloadMemberXmlJob");
            jobScheduler.RemoveJob(tenantId, "SftpUpdateJob");


            //jobScheduler.AddJob(tenantId, "ProcessEventQueueJob", typeof(ProcessEventQueueJob), null, "0 0/2 * * * ?");

            //jobScheduler.AddJob(tenantId, "ProcessMissedEventsJob", typeof(ProcessMissedEventsJob), null, "0 0/5 * * * ?");

           
            //jobScheduler.AddJob(tenantId, "DownloadMemberXmlJob", typeof(DownloadMemberXmlJob), null, "0 0/2 * * * ?");

           
            //jobScheduler.AddJob(tenantId, "SftpUpdateJob", typeof(SftpUpdateJob), null, "0 0/2 * * * ?");



            //var jobParam = new Dictionary<string, object> { { "ProcessedDownloadedFiles", false }, { "siteId", _apiContext.SiteId } };
            //jobScheduler.AddJob(tenantId, "ImportEdgeMemberJob", typeof(ImportEdgeMemberJob), jobParam, "0 0/3 * * * ?");

        



            //jobScheduler.AddJob(tenantId, "ImportEdgeMemberJob", typeof(ProcessEventQueueJob), null, "0 0/2 * * * ?");
            //jobScheduler.AddJob(tenantId, "ProcessEventQueueJob", typeof(ProcessEventQueueJob), null, "0 0/3 * * * ?");
            //jobScheduler.AddJob(tenantId, "ProcessMissedEventsJob", typeof(ProcessEventQueueJob), null, "0 0/5 * * * ?");
        }


    }
}
