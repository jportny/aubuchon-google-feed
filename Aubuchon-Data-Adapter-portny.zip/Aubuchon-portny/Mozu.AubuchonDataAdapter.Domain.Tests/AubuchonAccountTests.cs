﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Autofac;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.Contracts.Customer;
using Mozu.Api.Resources.Commerce.Customer;
using Mozu.Api.ToolKit.Config;
using Mozu.Api.ToolKit.Readers;
using Mozu.AubuchonDataAdapter.Domain.Contracts;
using Mozu.AubuchonDataAdapter.Domain.Handlers;
using Mozu.Api.Contracts.MZDB;


namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class AubuchonAccountTests : BaseTest
    {
        private IAppSetting _appSetting;
        IApiContext _apiContext;
        private IAubuchonAccountHandler _aubuchonAccountHandler;
        private IAccountPhoneHandler _accountPhoneHandler;

        [TestInitialize]
        public void Init()
        {
            _appSetting = Container.Resolve<IAppSetting>();
            _apiContext = new ApiContext(TenantId, SiteId);
            //_apiContext = new ApiContext(11673, 15824);
            _aubuchonAccountHandler = new AubuchonAccountHandler(_appSetting);
            _accountPhoneHandler = new AccountPhoneHandler(_appSetting);
        }
        [TestMethod]
        public void GetLocations() 
        {
            var locationResource = new Mozu.Api.Resources.Commerce.LocationResource(_apiContext);
            var adminLocResource = new Mozu.Api.Resources.Commerce.Admin.LocationResource(_apiContext);
            var locations = adminLocResource.GetLocationsAsync(0, 200).Result;

            try
            {
                string _listFullName = MzdbHelper.GetListFullName(_appSetting, "LocationExtra");
                string _listNS = MzdbHelper.GetListNameSpace(_appSetting);

                var locationExtraList = new EntityList(){
                    IsSandboxDataCloningSupported = true,
                    IsVisibleInStorefront = true,
                    Name = "LocationExtra",
                    NameSpace = _listNS
                };
                var idProperty = new IndexedProperty { DataType="string", PropertyName="LocationCode" };

                //var indexProperties = new List
                
            }
            catch (AggregateException exc) 
            {
            
            }
                
        }

        [TestMethod]
        public async Task FixPhoneNumberPreLive()
        {
            var custReader = new CustomerAccountReader
            {
                Context = _apiContext,
                PageSize = 200,
                ResponseFields = "Contacts"
            };

            
            while (await custReader.ReadAsync())
            {
                await custReader.Items.ForEachAsync(10, async account =>
                {
                    await AddUpdateAccountPhone(_apiContext.TenantId, account, StatusCode.New);
                });
            }

            
        }

        private async Task AddUpdateAccountPhone(int tenantId, CustomerAccount account, StatusCode statusCode)
        {
            foreach (var phone in account.Contacts.SelectMany(contact => BuildAccountPhones(account, contact.PhoneNumbers.Home, contact.PhoneNumbers.Mobile, contact.PhoneNumbers.Work)))
            {
                await
                    _accountPhoneHandler.UpsertAccountPhoneAsync(tenantId, phone);
            }
        }

        private static IEnumerable<AccountPhone> BuildAccountPhones(CustomerAccount account, params string[] phoneNumbers)
        {
            return (from phoneNumber in phoneNumbers
                    where !String.IsNullOrEmpty(phoneNumber)
                    select new AccountPhone
                    {
                        AccountId = account.Id,
                        Id = String.Format("{0}-{1}", account.Id, phoneNumber),
                        Phone = phoneNumber
                    }).ToList();
        }


        [TestMethod]
        public async Task Phone_Lookup()
        {
            var apiContext = new ApiContext(TenantId, SiteId);
            apiContext = new ApiContext(11673, 15824);
            var phoneNumber = "5083314423";
            var customerAccountResource = new CustomerAccountResource(apiContext);
            var contactList = new List<object>();

            var contacts = await _accountPhoneHandler.GetAccountsWithPhone(11673, phoneNumber);
            if (!contacts.Any())
            {
                Console.WriteLine("Does not exist");
                return;
            }
            foreach (var contact in contacts)
            {
                var account = await customerAccountResource.GetAccountAsync(contact.AccountId);
                if (!await account.IsPreLiveCustomer(apiContext)) continue;
                var billingAddr = account.Contacts.Any()
                    ? account.Contacts.FirstOrDefault(
                        c =>
                            c.Types.Any(
                                t => t.IsPrimary && t.Name.Equals("Billing", StringComparison.InvariantCultureIgnoreCase))) : null
                ;

                //Pick the first address if there is no primary billing address
                if (billingAddr == null && account.Contacts.Any())
                {
                    billingAddr = account.Contacts.First();
                }

                var homeUser = account.Segments.FirstOrDefault(s => s.Code.Equals(SegmentConstants.HomeTeam, StringComparison.InvariantCultureIgnoreCase)) != null ? "1" : "0";
                var homeUserPro = account.Segments.FirstOrDefault(s => s.Code.Equals(SegmentConstants.HomeTeamPro, StringComparison.InvariantCultureIgnoreCase)) != null ? "1" : "0";
                var ct =
                    new
                    {
                        Id = contact.AccountId,
                        S = new[] { homeUser, homeUserPro },
                        FN = account.FirstName,
                        LN = account.LastName,
                        EM = account.EmailAddress,
                        R = account.IsAnonymous ? "0" : "1",
                        CY = billingAddr != null ? billingAddr.Address.CityOrTown : "",
                        ST = billingAddr != null ? billingAddr.Address.StateOrProvince : ""
                    };

                contactList.Add(ct);
            }
        }

        [TestMethod]
        public void IsPreliveAccount()
        {
            const int accountId = 116615;
            var accountHandler = new Mozu.Api.Resources.Commerce.Customer.Accounts.CustomerAttributeResource(_apiContext);
            var existingPreLive = accountHandler.GetAccountAttributeAsync(accountId, AttributeConstants.ExistingAccountPreLive).Result;
            var isPrelive = existingPreLive != null && existingPreLive.Values.Count > 0 &&
                            (bool) existingPreLive.Values[0];
            Assert.IsTrue(isPrelive);
        }

        [TestMethod]
        public void IsEdgeImportCustomerTest()
        {
            var customerResource = new CustomerAccountResource(_apiContext);
            var account = customerResource.GetAccountAsync(230181).Result;
            var attr = AttributeConstants.PostLiveEdgeAccount;
            var ispostlive = account.Attributes.Any(a => a.FullyQualifiedName.Equals(AttributeConstants.PostLiveEdgeAccount, StringComparison.InvariantCultureIgnoreCase));

            Assert.IsTrue(account.IsEdgeImportCustomer(_apiContext).Result);
        }

        [TestMethod]
        public void ToPreliveCustomerTest()
        {
            var customerResource = new CustomerAccountResource(_apiContext);
            var account = customerResource.GetAccountAsync(5831).Result;
            account.ToPreLiveCustomer(_apiContext).Wait();
        }

        [TestMethod]
        public async Task Should_Create_Aubuchon_Customer_Using_Mozu_Account()
        {
            var customerResource = new CustomerAccountResource(_apiContext);
            var account = await customerResource.GetAccountAsync(1057);

            var aubuchonCustomerId = await _aubuchonAccountHandler.AddUpdateAccountAsync(account);
            account.ExternalId = aubuchonCustomerId;

            await customerResource.UpdateAccountAsync(account, 1057, "Id,ExternalId");
            Console.WriteLine("Aubuchon Customer Id " + aubuchonCustomerId);

        }
        [TestMethod]
        public async Task Test_Get_Reward_Points() {

            var customerResource = new CustomerAccountResource(_apiContext);
            var account = await customerResource.GetAccountAsync(116285);

            var points = _aubuchonAccountHandler.GetCustomerRewardPoints(_apiContext, account.Id).Result;
           
            Console.WriteLine("Reward Points " + points);
        }
        [TestMethod]
        public async Task Should_Get_Aubuchon_Customer()
        {
            var account = await _aubuchonAccountHandler.GetCustomer("1000009635|0");
            Console.WriteLine(account.ExternalId);
        }

        [TestMethod]
        public async Task InstallAccountPhoneSchema()
        {
            await _accountPhoneHandler.InstallAccountPhoneSchema(TenantId);
        }
    }
}
