﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Autofac;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.Contracts.Customer;
using Mozu.Api.Contracts.Event;
using Mozu.Api.Resources.Commerce.Customer;
using Mozu.Api.Resources.Commerce.Customer.Accounts;
using Mozu.Api.ToolKit.Config;
using Mozu.Api.ToolKit.Readers;
using Mozu.AubuchonDataAdapter.Domain.Contracts;
using Mozu.AubuchonDataAdapter.Domain.Events;
using Mozu.AubuchonDataAdapter.Domain.Handlers;
using Mozu.AubuchonDataAdapter.Domain.Jobs;


namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class JobsTest : BaseTest
    {
        private IAppSetting _appSetting;
        private IEventHandler _eventHandler;
        private IEventProcessor _eventProcessor;
        private IAubuchonAccountHandler _aubuchonAccountHandler;
        private IAccountPhoneHandler _accountPhoneHandler;


        [TestInitialize]
        public void Init()
        {
            _appSetting = Container.Resolve<IAppSetting>();
            _eventHandler = Container.Resolve<IEventHandler>();
            _aubuchonAccountHandler = Container.Resolve<IAubuchonAccountHandler>();
            _accountPhoneHandler = Container.Resolve<IAccountPhoneHandler>();
            _eventProcessor = new AccountEventProcessor(_aubuchonAccountHandler, _eventHandler, _accountPhoneHandler,
                _appSetting);
        }

        [TestMethod]
        public void ExecuteJob_ProcessEventQueue()
        {
            try
            {


                var apiContext = new ApiContext(TenantId);
                var filter = String.Format("Status eq '{0}'", EventStatus.Pending);
                var events = _eventHandler.GetEvents(TenantId, filter).Result;

                foreach (var evt in events)
                {
                    var statusCode = StatusCode.New;
                    if (evt.Topic.Contains(".updated"))
                    {
                        statusCode = StatusCode.Active;
                    }

                    _eventProcessor.ProcessEvent(apiContext, evt.ToMozuEvent(), statusCode).Wait();
                }
                _eventHandler.PurgeOldEvents(apiContext).Wait();

            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        [TestMethod]
        public async Task ExecuteJob_ProcessMissedEvents()
        {
            var apiContext = new ApiContext(TenantId);
            DateTime? lastRunTime = DateTime.Now.AddMinutes(-5);

            //get events since last run
            var filter = string.Empty;
            if (lastRunTime.HasValue)
                filter = String.Format("createDate gt '{0}'", lastRunTime.Value.ToString("u"));

            var eventReader = new EventReader { Context = apiContext, Filter = filter, PageSize = 200 };
            var eventList = new List<Event>();
            while (await eventReader.ReadAsync())
            {
                eventList.AddRange(eventReader.Items);
            }

            if (!eventList.Any()) return;

            var concise = from record in eventList
                          group record by new { record.EntityId, record.Topic }
                              into g
                              let recent = (
                                  from groupedItem in g
                                  orderby groupedItem.AuditInfo.UpdateDate descending
                                  select groupedItem
                                  ).First()
                              select recent;


            foreach (var evt in concise)
            {
                if (!evt.IsApproved()) continue;

                var aubEvent = evt.ToAubEvent();

                var entFilter = String.Format("Id eq '{0}' and Status eq 'Processed'", aubEvent.Id);
                var evtInEntity = await _eventHandler.GetEvents(apiContext.TenantId, entFilter);
                var evtList = evtInEntity.ToList();

                if (evtList.Any())
                {
                    var ent = evtList.FirstOrDefault();
                    if (ent != null && ent.ProcessedDateTime > evt.AuditInfo.UpdateDate) continue;
                }

                var statusCode = StatusCode.New;
                if (evt.Topic.Contains(".updated"))
                {
                    statusCode = StatusCode.Active;
                }

                await _eventProcessor.ProcessEvent(apiContext, evt, statusCode);
            }
        }

        [TestMethod]
        public async Task ImportEdgeMemberJob()
        {
            var apiContext = new ApiContext(TenantId,SiteId);
            var isLive = _appSetting.Settings.ContainsKey("IsLive") && Convert.ToBoolean(_appSetting.Settings["IsLive"]);
            isLive = true;
            var edgeFtpHostDirectory = ConfigurationManager.AppSettings["EdgeFTPHostDirectory"];
            var edgeImportTempDirectory = ConfigurationManager.AppSettings["EdgeImportTempDirectory"];

            var sftpHandler = new SftpHandler(_appSetting);

            var fileNames = new List<string>(Directory.GetFiles(edgeImportTempDirectory).Select(Path.GetFileName)
                                 .ToArray());

            if (!fileNames.Any())
            {
                fileNames = new List<string>();
                Console.WriteLine("Fetching files from SFTP");
                sftpHandler.GetFiles(edgeImportTempDirectory
                    , edgeFtpHostDirectory
                    , fileNames);
            }
            else
            {
                Console.WriteLine("Found downloaded files to process");
            }
            var processedFiles = new List<String>();
            var failedFiles = new List<String>();

            var customerContactResource = new CustomerContactResource(apiContext);

            //await fileNames.ForEachAsync(10, async file =>
            foreach (var file in fileNames)
            {
                try
                {
                    var serializer = new XmlSerializer(typeof(EdgeMessage));
                    var reader = new StreamReader(edgeImportTempDirectory + @file);
                    var edgeMessage = (EdgeMessage)serializer.Deserialize(reader);
                    reader.Close();

                    var memberBody =
                        (EdgeMessageBody)
                            edgeMessage.Items.Where(em => em is EdgeMessageBody).Select(em => em).FirstOrDefault();
                    if (memberBody == null) return;
                    var member = memberBody.Member.Any() ? memberBody.Member.First() : null;
                    if (member == null) continue;

                    //foreach (var member in memberBody.Member.AsEnumerable())
                    //{
                    var memberNumber = member.memberNumber;
                    var customerAccount = new CustomerAccount();
                    var customerAccountResource = new CustomerAccountResource(apiContext);
                    if (String.IsNullOrEmpty(memberNumber))
                    {
                        Console.WriteLine(String.Format("Member number is missing. Member Id: {0}",
                            member.memberID));
                    }
                    else
                    {
                        var accounts =
                            await
                                customerAccountResource.GetAccountsAsync(filter:
                                    String.Format("ExternalId eq {0}", memberNumber.Trim()));
                        customerAccount = accounts.Items.FirstOrDefault() ?? new CustomerAccount();
                    }
                    //Removed this line to ensure that Imported edge customers are added to mozu
                    //even if they dont have Aubuchon Id
                    //if (customerAccount.Id != 0)
                    //{
                    //    var customer = await customerAccountResource.GetAccountAsync(customerAccount.Id, "Id");
                    //    if (customer == null)
                    //    {
                    //        continue;
                    //    }
                    //}


                    customerAccount.FirstName = member.nameFirst.ToTitleCase();
                    customerAccount.LastName = member.nameLast.ToTitleCase();
                    customerAccount.EmailAddress = member.email;
                    customerAccount.TaxId = member.taxNumber;

                    customerAccount.CompanyOrOrganization = member.organization;
                    customerAccount.LocaleCode = member.locale;
                    customerAccount.ExternalId = member.memberNumber;


                    if (customerAccount.Id != 0)
                        await
                            customerAccountResource.UpdateAccountAsync(customerAccount, customerAccount.Id,
                                "Contacts");
                    else
                    {
                        customerAccount = await customerAccountResource.AddAccountAsync(customerAccount);
                        customerAccount = await customerAccountResource.GetAccountAsync(customerAccount.Id);
                        //Missing attributes in the previous return value
                        if (isLive)
                        {
                            var customerLoginInfo = new CustomerLoginInfo
                            {
                                Username = member.username,
                                EmailAddress = member.email,
                                IsImport = true,
                                Password = CreatePassword()
                            };
                            await
                                customerAccountResource.AddLoginToExistingCustomerAsync(customerLoginInfo,
                                    customerAccount.Id);

                        }

                    }

                    //Add segments if any
                    foreach (var group in member.groups)
                    {
                        await _aubuchonAccountHandler.AddToSegment(apiContext, customerAccount.Id, group.groupCode.ToUpper());
                    }

                    // Set the “ImportEdgeCustomer” attribute to true
                    await customerAccount.ToEdgeImportCustomer(apiContext);

                    if (!isLive)
                    {
                        await customerAccount.ToPreLiveCustomer(apiContext);
                    }


                    //Add or update contacts

                    foreach (var address in member.addresses)
                    {
                        var addressType = address.addressObjTypeCode;
                        
                        CustomerContact customerContact = null;
                        if (addressType.Equals("Billto", StringComparison.InvariantCultureIgnoreCase))
                        {
                            customerContact =
                                       customerAccount.Contacts.FirstOrDefault(
                                           a => (a.Types != null && a.Types.Any(t => t != null && t.Name == "Billing")));
                        }
                        else if (addressType.Equals("Shipto", StringComparison.InvariantCultureIgnoreCase))
                        {
                            customerContact =
                                       customerAccount.Contacts.FirstOrDefault(
                                           a => (a.Types != null && a.Types.Any(t => t != null && t.Name == "Shipping")));
                        }

                        if (customerContact == null && customerAccount.Contacts.Any())
                            customerContact = customerAccount.Contacts.FirstOrDefault();

                        if (customerContact == null)
                        {
                            customerContact = new CustomerContact
                            {
                                AccountId = customerAccount.Id,
                                Address = new Api.Contracts.Core.Address(),
                                PhoneNumbers = new Api.Contracts.Core.Phone(),
                                AuditInfo = new Api.Contracts.Core.AuditInfo()
                            };
                        }

                        customerContact.Types = new List<ContactType>
                        {
                            new ContactType
                            {
                                Name =
                                    address.addressObjTypeCode.Equals("BillTo",StringComparison.CurrentCultureIgnoreCase)
                                        ? "Billing"
                                        : "Shipping",
                                        IsPrimary = address.primaryForType.Equals("true",StringComparison.InvariantCultureIgnoreCase)
                            }
                        };


                        customerContact.Address.Address1 = address.address1;
                        customerContact.Address.Address2 = address.address2;
                        customerContact.Address.Address3 = address.address3;
                        customerContact.Address.CityOrTown = address.city;
                        customerContact.Address.StateOrProvince = address.stateProvinceCode;
                        customerContact.Address.CountryCode = address.countryCode;
                        customerContact.Address.PostalOrZipCode = address.postalCode;
                        customerContact.Email = address.email;
                        customerContact.FirstName = address.nameFirst.ToTitleCase();
                        customerContact.LastNameOrSurname = address.nameLast.ToTitleCase();
                        customerContact.MiddleNameOrInitial = address.nameMiddle.ToTitleCase();
                        customerContact.CompanyOrOrganization = address.organization;
                        customerContact.PhoneNumbers.Home = address.phoneHome;
                        customerContact.PhoneNumbers.Mobile = address.phoneCell;
                        customerContact.PhoneNumbers.Work = address.phoneWork;
                        customerContact.FaxNumber = address.fax;
                        customerContact.Address.AddressType = bool.Parse(address.isResidential)
                            ? "Residential"
                            : "";
                        customerContact.Label = address.salutation;
                        customerContact.AuditInfo.CreateDate = Convert.ToDateTime(address.createDate);
                        customerContact.AuditInfo.UpdateDate = Convert.ToDateTime(address.lastUpdated);

                        if (customerContact.Id != 0)
                            await
                                customerContactResource.UpdateAccountContactAsync(customerContact,
                                    customerAccount.Id, customerContact.Id);
                        else
                            await
                                customerContactResource.AddAccountContactAsync(customerContact,
                                    customerAccount.Id);
                    }

                    /*

                    foreach (
                        ImportEdgeMemberJob.AddressTypes addressType in
                            Enum.GetValues(typeof(ImportEdgeMemberJob.AddressTypes)))
                    {
                        CustomerContact customerContact = null;
                        switch (addressType)
                        {
                            case Jobs.ImportEdgeMemberJob.AddressTypes.Billto:
                                {
                                    customerContact =
                                        customerAccount.Contacts.FirstOrDefault(
                                            a => (a.Types != null && a.Types.Any(t => t != null && t.Name == "Billing")));
                                }
                                break;
                            case Jobs.ImportEdgeMemberJob.AddressTypes.Shipto:
                                {
                                    customerContact =
                                        customerAccount.Contacts.FirstOrDefault(
                                            a => (a.Types != null && a.Types.Any(t => t != null && t.Name == "Shipping")));
                                }
                                break;
                        }

                        var customerContactResource = new CustomerContactResource(apiContext);
                        var address =
                            member.addresses.FirstOrDefault(
                                a =>
                                    a.addressObjTypeCode.Equals(addressType.ToString(),
                                        StringComparison.CurrentCultureIgnoreCase));
                        if (address == null && customerContact != null)
                        {
                            await
                                customerContactResource.DeleteAccountContactAsync(customerContact.AccountId,
                                    customerContact.Id);
                            continue;
                        }

                        if (customerContact == null)
                        {
                            customerContact = new CustomerContact
                            {
                                AccountId = customerAccount.Id,
                                Address = new Api.Contracts.Core.Address(),
                                PhoneNumbers = new Api.Contracts.Core.Phone(),
                                AuditInfo = new Api.Contracts.Core.AuditInfo()
                            };
                            
                        }
                        if (address == null) continue;
                        customerContact.Types = new List<ContactType>
                        {
                            new ContactType
                            {
                                Name =
                                    address.addressObjTypeCode.ToLower()
                                        .Equals(Jobs.ImportEdgeMemberJob.AddressTypes.Billto.ToString(),
                                            StringComparison.CurrentCultureIgnoreCase)
                                        ? "Billing"
                                        : "Shipping"
                            }
                        };

                        customerContact.Address.Address1 = address.address1;
                        customerContact.Address.Address2 = address.address2;
                        customerContact.Address.Address3 = address.address3;
                        customerContact.Address.CityOrTown = address.city;
                        customerContact.Address.StateOrProvince = address.stateProvinceCode;
                        customerContact.Address.CountryCode = address.countryCode;
                        customerContact.Address.PostalOrZipCode = address.postalCode;
                        customerContact.Email = address.email;
                        customerContact.FirstName = address.nameFirst.ToTitleCase();
                        customerContact.LastNameOrSurname = address.nameLast.ToTitleCase();
                        customerContact.MiddleNameOrInitial = address.nameMiddle.ToTitleCase();
                        customerContact.CompanyOrOrganization = address.organization;
                        customerContact.PhoneNumbers.Home = address.phoneHome;
                        customerContact.PhoneNumbers.Mobile = address.phoneCell;
                        customerContact.PhoneNumbers.Work = address.phoneWork;
                        customerContact.FaxNumber = address.fax;
                        customerContact.Address.AddressType = bool.Parse(address.isResidential)
                            ? "Residential"
                            : "";
                        customerContact.Label = address.salutation;
                        customerContact.AuditInfo.CreateDate = Convert.ToDateTime(address.createDate);
                        customerContact.AuditInfo.UpdateDate = Convert.ToDateTime(address.lastUpdated);

                        customerAccount.Contacts.Add(customerContact);

                        if (customerContact.Id != 0)
                            await
                                customerContactResource.UpdateAccountContactAsync(customerContact,
                                    customerAccount.Id, customerContact.Id);
                        else
                            await
                                customerContactResource.AddAccountContactAsync(customerContact,
                                    customerAccount.Id);
                    }

                    */

                    processedFiles.Add(file);

                    

                    //}
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error processing files in EdgeMemberImport", ex);
                    failedFiles.Add(file);
                   
                }


          
            }
            foreach (var fileName in processedFiles)
            {
                try
                {
                    sftpHandler.RemoveFile(String.Format("{0}/{1}", edgeFtpHostDirectory, fileName));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                try
                {
                    File.Delete(String.Format("{0}{1}", edgeImportTempDirectory, fileName));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

            foreach (var fileName in failedFiles)
            {
                try
                {
                    sftpHandler.MoveFile(
                        String.Format("{0}/{1}", edgeFtpHostDirectory, fileName),
                        String.Format("{0}/failed/{1}", edgeFtpHostDirectory, fileName)
                        );
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                try
                {
                    var destinationFile = String.Format(@"{0}failed\{1}", edgeImportTempDirectory, fileName);

                    if (File.Exists(destinationFile))
                        File.Delete(destinationFile);

                    File.Move(
                        String.Format("{0}{1}", edgeImportTempDirectory, fileName),
                        destinationFile
                        );
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }


        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private static string CreatePassword()
        {
            var characters = CreateRandomPassword("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmonpqrstuvwxyz", 8);
            var numbers = CreateRandomPassword("0123456789", 4);
            return String.Format("{0}{1}", characters, numbers);
        }

        private static string CreateRandomPassword(string chars,int passwordLength)
        {
            var random = new Random();
            return new string(Enumerable.Repeat(chars, passwordLength)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}
