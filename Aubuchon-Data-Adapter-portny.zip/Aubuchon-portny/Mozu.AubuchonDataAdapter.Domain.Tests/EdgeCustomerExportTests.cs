﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Autofac;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.Contracts.Customer;
using Mozu.Api.Resources.Commerce.Customer;
using Mozu.Api.Resources.Commerce.Customer.Accounts;
using Mozu.Api.Resources.Commerce.Customer.Attributedefinition;
using Mozu.Api.ToolKit.Config;
using Mozu.AubuchonDataAdapter.Domain.Contracts;
using Mozu.AubuchonDataAdapter.Domain.Handlers;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class EdgeCustomerExportTests : BaseTest
    {
        private IEdgeCustomerExportHandler _edgeCustomerExportHandler;
        private IAubuchonAccountHandler _aubuchonAccountHandler;
        private IEventHandler _eventHandler;
        private IAppSetting _appSetting;
        IApiContext _apiContext;

        [TestInitialize]
        public void Init()
        {
            _appSetting = Container.Resolve<IAppSetting>();
            _eventHandler = Container.Resolve<IEventHandler>();
            _edgeCustomerExportHandler = new EdgeCustomerExportHandler(_appSetting);
            _aubuchonAccountHandler = new AubuchonAccountHandler(_appSetting);
            _apiContext = new ApiContext(TenantId, SiteId);
        }

        [TestMethod]
        public void Should_Get_Member_Import_Message()
        {
            var customerResource = new CustomerAccountResource(_apiContext);
            var account = customerResource.GetAccountAsync(242861).Result;
            var xml = _edgeCustomerExportHandler.BuildCustomerExportMessageAsync(_apiContext, account, StatusCode.Active);
        }

        [TestMethod]
        public async Task Should_Update_Existing_Prelive_Attribute()
        {
            var customerResource = new CustomerAccountResource(_apiContext);
            var customerAccount = await customerResource.GetAccountAsync(12312);
            var attributeResource = new AttributeResource(_apiContext);
            var attribute = await attributeResource.GetAttributeAsync("tenant~existing-account-pre-live");
            var customerAttributeResource = new CustomerAttributeResource(_apiContext);
            var customerAttribute =
                await customerAttributeResource.GetAccountAttributeAsync(customerAccount.Id, attribute.AttributeFQN) ??
                new CustomerAttribute { AttributeDefinitionId = attribute.Id, FullyQualifiedName = "tenant~existing-account-pre-live" };

            customerAttribute.Values = new List<object> { false };

            if (customerAccount.Attributes.All(s => s.AttributeDefinitionId != attribute.Id))
                await customerAttributeResource.AddAccountAttributeAsync(customerAttribute, customerAccount.Id, attribute.AttributeFQN);
            else
                await customerAttributeResource.UpdateAccountAttributeAsync(customerAttribute, customerAccount.Id, attribute.AttributeFQN);

            //await
            //    customerAttributeResource.DeleteAccountAttributeAsync(customerAccount.Id,
            //        "tenant~existing-account-pre-live");
        }

        [TestMethod]
        public async Task ShouldIgnoreCustomer()
        {
            const int accountId = 1060;
            var resource = new CustomerAccountResource(_apiContext);
            var account = await resource.GetAccountAsync(accountId, "Id,IsAnonymous,Attributes,AuditInfo");
            var updateRecently = account.AuditInfo.UpdateDate > DateTime.Now.AddMinutes(-5);

            var filter = String.Format("Id eq '{0}-customeraccount.updated' and Status eq 'Processed'", account.Id);
            var accountEventObj = await _eventHandler.GetEvents(_apiContext.TenantId, filter);
            var accountEvent = accountEventObj.FirstOrDefault();

            if (accountEvent != null)
            {
                Console.WriteLine(accountEvent.ProcessedDateTime + " " + DateTime.Now.AddSeconds(-60) + " " + DateTime.Compare(Convert.ToDateTime(accountEvent.ProcessedDateTime),DateTime.Now.AddSeconds(-60)));
                if (DateTime.Compare(Convert.ToDateTime(accountEvent.ProcessedDateTime),DateTime.Now.AddSeconds(-60)) > 0)
                {
                    Console.WriteLine("ignore");
                };
            }


            //if (_isLive)
            //{
            //    return account.IsAnonymous || await account.IsEdgeImportCustomer(apiContext);
            //}
            var shouldIgnore = account.IsAnonymous || account.IsEdgeImportCustomer() || updateRecently;
            Assert.IsTrue(shouldIgnore);
        }


        [TestMethod]
        public async Task Should_Update_Edge_Member()
        {
            var customerResource = new CustomerAccountResource(_apiContext);
            var account = await customerResource.GetAccountAsync(1000);
            await _edgeCustomerExportHandler.ExportCustomerAsync(_apiContext, account, StatusCode.New);
        }

        [TestMethod]
        public async Task Should_Add_Customer_To_HomeTeam_Segment()
        {
            await _aubuchonAccountHandler.AddToSegment(_apiContext, 1000, "hometeam");
        }

        [TestMethod]
        public async Task Should_Add_PhoneNumbers_To_Custom_Attributes()
        {
            const string phoneAttribFqn = "tenant~test_phone";
            const int accountId = 1000;

            var attrResource = new AttributeResource(_apiContext);

            var attr = await attrResource.GetAttributeAsync(phoneAttribFqn);

            var customerResource = new CustomerAccountResource(_apiContext);
            var customerAttribResource = new CustomerAttributeResource(_apiContext);
            var account = await customerResource.GetAccountAsync(accountId).ConfigureAwait(false);

            //AddEvent PhoneNumbers to Custom Attributes
            var phoneAttributes = account.Attributes.Where(a => a.FullyQualifiedName == phoneAttribFqn).ToList();
            if (phoneAttributes.Any())
            {
                await customerAttribResource.DeleteAccountAttributeAsync(accountId, phoneAttribFqn);
            }
            var phoneAttrib = new CustomerAttribute {FullyQualifiedName = phoneAttribFqn, Values = new List<object>(), AttributeDefinitionId = attr.Id};
            foreach (var contact in account.Contacts)
            {
                if (!String.IsNullOrEmpty(contact.PhoneNumbers.Home) && !phoneAttrib.Values.Contains(contact.PhoneNumbers.Home)) phoneAttrib.Values.Add(contact.PhoneNumbers.Home);
                if (!String.IsNullOrEmpty(contact.PhoneNumbers.Mobile) && !phoneAttrib.Values.Contains(contact.PhoneNumbers.Mobile)) phoneAttrib.Values.Add(contact.PhoneNumbers.Mobile);
                if (!String.IsNullOrEmpty(contact.PhoneNumbers.Work) && !phoneAttrib.Values.Contains(contact.PhoneNumbers.Work)) phoneAttrib.Values.Add(contact.PhoneNumbers.Work);
            }
            await customerAttribResource.AddAccountAttributeAsync(phoneAttrib, accountId).ConfigureAwait(false);
            var filter = String.Format("Attributes.Name eq '{0}' and Attributes.Value eq '{1}'", phoneAttribFqn, "5129999999");
            var filtered = await customerResource.GetAccountsAsync(null, null, null, filter);
        }
    }
}
