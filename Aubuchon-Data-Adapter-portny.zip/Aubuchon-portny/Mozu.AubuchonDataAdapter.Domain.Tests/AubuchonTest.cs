﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Newtonsoft.Json;
using Mozu.Api.Contracts.CommerceRuntime.Orders;
using System.Collections.Generic;
using System.Collections;
using Mozu.Api.Contracts.CommerceRuntime.Discounts;
using MozuPayment = Mozu.Api.Contracts.CommerceRuntime.Payments.Payment;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class AubuchonTest
    {
       

        [TestMethod]
        public void TestJsonOrder()
        {
            string text = System.IO.File.ReadAllText("SampleOrder/Payload-2.txt");
            var order = JsonConvert.DeserializeObject<Order>(text);

            SplitOrders(order);
        }

        private void SplitOrders(Order order)
        {
            
            ArrayList toStoreIds = new ArrayList();
            foreach (OrderAttribute attribute in order.Attributes)
            {
                System.Console.WriteLine(attribute.FullyQualifiedName);
                foreach (String obj in attribute.Values)
                {
                    string[] values = obj.Split(':');
                    if (values.Length == 2)
                        toStoreIds.Add(values[1]);
                }
            }

            Dictionary<string, List<OrderItem>> result = new Dictionary<string, List<OrderItem>>();
            result["toStore"] = new List<OrderItem>();
            result["Ship"] = new List<OrderItem>();
            result["Pickup"] = new List<OrderItem>();
           
            foreach (OrderItem item in order.Items)
            {
                System.Console.WriteLine("ITEM Fulfillment Method: " + item.FulfillmentMethod);
                if (toStoreIds.Contains(item.Product.ProductCode))
                {
                    result["toStore"].Add(item);
                    continue;
                }
                if (item.FulfillmentMethod == "Ship")
                {
                    result["Ship"].Add(item);
                    continue;
                }
                if (item.FulfillmentMethod == "Pickup")
                {
                    result["Pickup"].Add(item);
                    continue;
                }
            }

            List<Order> splitOrders = new List<Order>();
            foreach (String key in result.Keys)
            {
                List<OrderItem> select = result[key];

                Order splitted = CalculateTotal(select);
                if (key == "Ship")
                {
                    foreach (ShippingDiscount discount in order.ShippingDiscounts)
                    {
                        splitted.DiscountTotal += discount.Discount.Impact;
                        splitted.DiscountedTotal -= discount.Discount.Impact;
                    }
                    splitted.ShippingSubTotal = order.ShippingSubTotal;
                }
                splitOrders.Add(splitted);
            }

            splitOrders.Sort(delegate(Order x, Order y)
            {
                if (x.Total == y.Total) return 0;
                if (x.Total < y.Total) return -1;
                return 1;
            });

            List<MozuPayment> payments = order.Payments;
            payments.Sort(delegate(MozuPayment x, MozuPayment y)
            {
                if (x.AmountRequested == y.AmountRequested) return 0;
                if (x.AmountRequested > y.AmountRequested) return -1;
                return 1;
            });

            Stack<MozuPayment> applicablePayments = new Stack<MozuPayment>(payments);

            ApplyPayments(splitOrders, applicablePayments);

            foreach (Order o in splitOrders)
            {
                Console.WriteLine("ORDER TOTAL " + o.Total);
                foreach (MozuPayment p in o.Payments)
                {
                    Console.Write("Payment Type :" + p.PaymentType);
                    Console.WriteLine("  Amount Requested: " + p.AmountRequested);
                }
            }
        }


        private MozuPayment clone(MozuPayment payment)
        {
            MozuPayment copy = new MozuPayment();

            copy.AmountCollected = payment.AmountCollected;
            copy.AmountCredited = payment.AmountCredited;
            copy.AmountRequested = payment.AmountRequested;
            copy.BillingInfo = payment.BillingInfo;
            copy.PaymentType = payment.PaymentType;
            copy.OrderId = payment.OrderId;
            copy.PaymentServiceTransactionId = payment.PaymentServiceTransactionId;

            return copy;
        }


        private Order CalculateTotal(List<OrderItem> orderitems)
        {
            System.Console.WriteLine("******************************* calculation ****************************");
            Order split = new Order();
            split.Items = new List<OrderItem>();
            split.Payments = new List<MozuPayment>();
            split.DiscountTotal = 0;
            split.DiscountedTotal = 0;
            split.Subtotal = 0;
            split.TaxTotal = 0;
            split.Total = 0;
            split.FeeTotal = 0;
            split.ItemTaxTotal = 0;
            split.Subtotal = 0;
            split.ShippingTotal = 0;
            split.ShippingSubTotal = 0;
            split.DiscountedSubtotal = 0;
            split.HandlingTaxTotal = 0;
            System.Console.WriteLine("THIS ORDER HAS " + orderitems.Count);
            foreach (OrderItem item in orderitems)
            {
                split.Subtotal += item.Subtotal;
                split.DiscountTotal += (item.Subtotal - item.TaxableTotal);
                split.DiscountedTotal += item.TaxableTotal;
                split.ShippingTotal += item.ShippingTotal;
                split.Total += item.Total;
                split.TaxTotal += item.ItemTaxTotal;
                split.ItemTaxTotal += item.ItemTaxTotal;
                split.DiscountedSubtotal += item.DiscountedTotal;
                split.HandlingTaxTotal += item.HandlingAmount;
                split.Items.Add(item);
            }
            return split;
        }

        private void ApplyPayments(List<Order> orders, Stack<MozuPayment> payments) 
        {
            foreach (Order order in orders)
            {
                decimal toCollect = (decimal) order.Total;

                while (toCollect > 0)
                {
                    MozuPayment payment = payments.Pop();
                    if (toCollect < payment.AmountRequested)
                    {
                        MozuPayment remainder = clone(payment);
                        remainder.AmountRequested = payment.AmountRequested - toCollect;
                        //remainder.AmountCollected -= payment.AmountCollected - toCollect;

                        payment.AmountRequested = toCollect;
                        order.Payments.Add(payment);

                        payments.Push(remainder);
                        toCollect = 0;
                        continue;
                    }

                    if (toCollect >= payment.AmountRequested)
                    {
                        toCollect -= payment.AmountRequested;
                        order.Payments.Add(payment);
                    }
                }
            }
        }
    }
}
