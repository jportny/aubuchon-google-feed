﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.Contracts.ProductAdmin;
using Mozu.Api.Resources.Commerce.Catalog.Admin.Attributedefinition.Producttypes;
using Mozu.Api.Resources.Commerce.Catalog.Admin.Products;
using Mozu.Api.ToolKit.Config;
using Mozu.AubuchonDataAdapter.Domain.Events;
using Mozu.AubuchonDataAdapter.Domain.Handlers;
using Mozu.AubuchonDataAdapter.Domain.Utility;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class InventoryEventTests : BaseTest
    {
        private IProductExportHandler _productExportHandler;
        private IAppSetting _appSetting;
        IApiContext _apiContext;

        [TestInitialize]
        public void Init()
        {

            _appSetting = Container.Resolve<IAppSetting>();
            _productExportHandler = new ProductExportHandler(_appSetting);
            _apiContext = new ApiContext(TenantId, SiteId);
        }

        [TestMethod]
        public  async Task OutofStockTest()
        {
             try
            {

                const string productCode = "100002";
                //const string dcCode = "991";

                //await ExportProductInventoryAsync(apiContext, eventPayLoad);

                //var notInDc = false;
                var productAttribResource = new ProductPropertyResource(_apiContext);

                var filter = String.Format("StockAvailable le 0 and UpdateDate gt '{0}'",
                    DateTime.Now.AddMinutes(-10).ToString("u"));
                var locations = await GetProductLocations(_apiContext, productCode, filter);

                var locationAttrib = await productAttribResource.GetPropertyAsync(productCode, AttributeConstants.LocationCode, "AttributeFQN,Values");
                if (locationAttrib.AttributeFQN != null)
                {
                    locationAttrib.AttributeFQN = locationAttrib.AttributeFQN.ToLower();
                    var hasChanges = false;

                    //if (locationAttrib.Values == null)
                    //{
                    //    notInDc = true;
                    //}
                    //else
                    //{
                    foreach (
                        var item in
                            locations.Select(
                                location =>
                                    locationAttrib.Values.Where(p => p != null && Convert.ToString(p.Value).ToLower().Equals(location.LocationCode))).ToList()
                                .Where(item => item.Any()))
                    {
                        //if (item.Any(a => a.Value != null && Convert.ToString(a.Value).Equals(dcCode)))
                        //{
                        //    notInDc = true;
                        //}
                        locationAttrib.Values.Remove(item.First());
                        hasChanges = true;
                    }

                    if (hasChanges)
                        await
                            productAttribResource.UpdatePropertyAsync(locationAttrib, productCode,
                                AttributeConstants.LocationCode);
                    //}
                }

              
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        [TestMethod]
        public async Task InStockTest()
        {
            try
            {
                //const string dcCode = "991";
                const string productCode = "108238";
                Console.WriteLine(String.Format("Inventory in stock for {0}", productCode));
                //var locationInventoryResource =
                //    new LocationInventoryResource(apiContext);

                //await ExportProductInventoryAsync(apiContext, eventPayLoad);

                var productAttribResource = new ProductPropertyResource(_apiContext);
                var filter = String.Format("StockAvailable gt 0 and UpdateDate gt '{0}'",
                    DateTime.Now.AddMinutes(-5).ToString("u"));

                var locations = await GetProductLocations(_apiContext, productCode, filter);

                //var locations =
                //    await
                //        locationInventoryResource.GetLocationInventoriesAsync(productCode, filter: filter, pageSize: 200,
                //            responseFields: "Items(LocationCode),AuditInfo");



                //Add any new location to locationcode attribute

                var attributeResource = new Api.Resources.Commerce.Catalog.Admin.Attributedefinition.AttributeResource(_apiContext);
                var locationCodeAttrib = await attributeResource.GetAttributeAsync(AttributeConstants.LocationCode);
               
                var hasNewLocationCode = false;
                foreach (var loc in locations.Where(loc => !locationCodeAttrib.VocabularyValues.Any(
                    a => a.Value != null && a.Content != null && Convert.ToString(a.Value).Equals(loc.LocationCode))))
                {
                    locationCodeAttrib.VocabularyValues.Add(new AttributeVocabularyValue { Value = loc.LocationCode });
                    
                    hasNewLocationCode = true;
                }

                if (hasNewLocationCode)
                    await attributeResource.UpdateAttributeAsync(locationCodeAttrib, AttributeConstants.LocationCode);

                const int baseProductTypeId = 1;

                //Add attribute to product type
                var hasNewProductTypeValue = false;

                var productTypePropertyResource = new ProductTypePropertyResource(_apiContext);

                var lcAttribute = await productTypePropertyResource.GetPropertyAsync(baseProductTypeId, AttributeConstants.LocationCode);

                foreach (
                    var loc in
                        locations)
                {
                    if (lcAttribute.VocabularyValues.Any(v => v.Value != null && Convert.ToString(v.Value).Equals(loc.LocationCode))) continue;

                    var val = new AttributeVocabularyValueInProductType
                    {
                        Value = loc.LocationCode,
                        Order = 0,
                        VocabularyValueDetail = new AttributeVocabularyValue { Value = loc.LocationCode, ValueSequence = 0, Content = new AttributeVocabularyValueLocalizedContent(){ StringValue = loc.LocationCode}}
                    };

                    lcAttribute.VocabularyValues.Add(val);
                    hasNewProductTypeValue = true;
                }

                if (hasNewProductTypeValue)
                    await
                        productTypePropertyResource.UpdatePropertyAsync(lcAttribute, baseProductTypeId, lcAttribute.AttributeFQN);


               
                lcAttribute.AttributeDetail.AttributeFQN = lcAttribute.AttributeFQN;
                lcAttribute.AttributeDetail.Namespace = lcAttribute.AttributeDetail.Namespace.ToLower();
                

                //Update Product Location Code attribute
                var locationAttrib = await productAttribResource.GetPropertyAsync(productCode, AttributeConstants.LocationCode);

                if (locationAttrib == null)
                {
                    foreach (var attr in locations.Select(location => new ProductProperty
                    {
                        AttributeFQN = locationCodeAttrib.AttributeFQN,
                        Values =
                            new List<ProductPropertyValue>
                            {
                                new ProductPropertyValue {Value = location.LocationCode}
                            }
                    }))
                    {
                        await productAttribResource.AddPropertyAsync(attr, productCode);
                    }
                }
                else
                {
                    locationAttrib.AttributeFQN = locationAttrib.AttributeFQN.ToLower();
                    var hasChanges = false;
                    foreach (var location in locations)
                    {
                        if (locationAttrib.Values != null && locationAttrib.Values.Any(a => a.Value.Equals(location.LocationCode))) continue;
                        if (locationAttrib.Values == null)
                        {
                            locationAttrib.Values = new List<ProductPropertyValue>();
                        }
                        locationAttrib.Values.Add(new ProductPropertyValue { Value = location.LocationCode });
                        hasChanges = true;
                    }
                    if (hasChanges)
                        await productAttribResource.UpdatePropertyAsync(locationAttrib, productCode, AttributeConstants.LocationCode);
                }


                //Check InDc Flag if DC code 991 is selected in LocationCode attribute.
                //if (locationAttrib != null && locationAttrib.Values.Any(v => v.Value != null && Convert.ToString(v.Value).Equals(dcCode)))
                //{
                //    var indcAttribute =
                //        await
                //            productAttribResource.GetPropertyAsync(productCode, AttributeConstants.InDc,
                //                "AttributeFQN,Values");
                //    var indc = new ProductProperty
                //    {
                //        AttributeFQN = AttributeConstants.InDc,
                //        Values =
                //            new List<ProductPropertyValue>
                //            {
                //                new ProductPropertyValue {Value = 1}
                //            }
                //    };
                //    if (indcAttribute == null)
                //    {

                //        await productAttribResource.AddPropertyAsync(indc, productCode);
                //    }
                //    else
                //    {
                //        await productAttribResource.UpdatePropertyAsync(indc, productCode, AttributeConstants.InDc);
                //    }
                //}
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        protected async Task<IList<LocationInventory>> GetProductLocations(IApiContext apiContext, string productCode, string filter = null)
        {
            var locations = new List<LocationInventory>();

            var inventoryReader = new ProductLocationInventoryReader
            {
                Context = apiContext,
                ProductCode = productCode,
                PageSize = 200,
                ResponseFields = "Items(LocationCode),AuditInfo",
                Filter = filter
            };
            while (await inventoryReader.ReadAsync())
            {
                locations.AddRange(inventoryReader.Items);
            }
            return locations;
        }

    }
}
