﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.Clients.Commerce.Customer;
using Mozu.Api.Clients.Commerce.Customer.Attributedefinition;
using Mozu.Api.Contracts.CommerceRuntime.Fulfillment;
using Mozu.Api.Contracts.Customer;
using Mozu.Api.Contracts.ProductAdmin;
using Mozu.Api.Resources.Commerce.Catalog.Admin.Attributedefinition;
using Mozu.Api.Resources.Commerce.Catalog.Admin.Attributedefinition.Producttypes;
using Mozu.Api.Resources.Commerce.Catalog.Admin.Products;
using Mozu.Api.Resources.Commerce.Catalog.Storefront;
using Mozu.Api.Resources.Commerce.Customer;
using Mozu.Api.Resources.Commerce.Customer.Accounts;
using Mozu.Api.Resources.Commerce.Orders;
using Mozu.Api.ToolKit.Readers;
using Attribute = Mozu.Api.Contracts.ProductAdmin.Attribute;
using Product = Mozu.Api.Contracts.CommerceRuntime.Products.Product;
using ProductResource = Mozu.Api.Resources.Commerce.Catalog.Admin.ProductResource;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{

    [TestClass]
    public class AdminTests : BaseTest
    {

        [TestMethod]
        public async Task GetProductType()
        {
            var apiContext = new ApiContext(TenantId, SiteId);
            //Add attribute to product type
            //var res = new ProductTypeResource(apiContext);
            //var baseProductType = await res.GetProductTypeAsync(1, "Id");
            var hasNewProductTypeValue = false;
            var resource = new ProductTypePropertyResource(apiContext);




            var lcAttribute = await resource.GetPropertyAsync(1, "tenant~lc");

            Console.WriteLine(lcAttribute.AttributeFQN);

            //foreach (
            //    var loc in
            //        locations.Items.Where(loc => !lcAttribute.VocabularyValues.Any(v => v.Value.Equals(loc.LocationCode))))
            //{
            //    var val = new AttributeVocabularyValueInProductType
            //    {
            //        Value = loc.LocationCode,
            //        VocabularyValueDetail = new AttributeVocabularyValue() { Value = loc.LocationCode, Content = new AttributeVocabularyValueLocalizedContent() { StringValue = loc.LocationCode } }
            //    };
            //    lcAttribute.VocabularyValues.Add(val);
            //    hasNewProductTypeValue = true;
            //}

            //if (hasNewProductTypeValue)
            //    await
            //        resource.UpdatePropertyAsync(lcAttribute, baseProductType.Id.GetValueOrDefault(),
            //            "tenant~lc");



        }

        [TestMethod]
        public async Task GetProductAttribute()
        {
            //Add any new location to locationcode attribute
            var apiContext = new ApiContext(TenantId, SiteId);
            var attributeResource = new AttributeResource(apiContext);
            var locationCodeAttrib = await attributeResource.GetAttributeAsync(AttributeConstants.LocationCode);
            var hasNewLocationCode = false;

            Console.WriteLine(locationCodeAttrib.AttributeFQN);

            //foreach (var loc in locations.Items.Where(loc => locationCodeAttrib.VocabularyValues.All(a => (string)a.Value != loc.LocationCode)))
            //{
            //    locationCodeAttrib.VocabularyValues.Add(new AttributeVocabularyValue() { Value = loc.LocationCode });
            //    hasNewLocationCode = true;
            //}

            //if (hasNewLocationCode)
            //    await attributeResource.UpdateAttributeAsync(locationCodeAttrib, AttributeConstants.LocationCode);
        }

        [TestMethod]
        public void SearchTest()
        {
            var apiContext = new ApiContext(TenantId, SiteId);
            var searchResource = new ProductSearchResultResource(apiContext: apiContext);
            var result = searchResource.SearchAsync("space", "tenant~lc eq 991", pageSize: 20, sortBy: "tenant~indc").Result;
            foreach (var item in result.Items)
            {
                var pop = item.Properties.FirstOrDefault(p => p.AttributeFQN == "tenant~indc");
                if (pop != null)
                {
                    var v = pop.Values.FirstOrDefault();
                    if (v == null) continue;
                    Console.WriteLine(v.Value);
                }
            }
        }

        public MozuUrl GetAttributesUrl(int? startIndex = null, int? pageSize = null, string sortBy = null, string filter = null, string responseFields = null)
        {
            var mozuUrl = new MozuUrl("/admin/app/customerattributes/create?startIndex={startIndex}&pageSize={pageSize}&sortBy={sortBy}&filter={filter}&responseFields={responseFields}", MozuUrl.UrlLocation.TENANT_POD, false);
            mozuUrl.FormatUrl("filter", (object)filter);
            mozuUrl.FormatUrl("pageSize", (object)pageSize);
            mozuUrl.FormatUrl("responseFields", (object)responseFields);
            mozuUrl.FormatUrl("sortBy", (object)sortBy);
            mozuUrl.FormatUrl("startIndex", (object)startIndex);
            return mozuUrl;
        }

        [TestMethod]
        public async Task Copy_Attributes()
        {

            var sourceContext = new ApiContext(11673, 15824);
            var targetContext = new ApiContext(15026, 21062);


            //Hack to seed customer attributes
            /*var customerAttributeResource =
                new Api.Resources.Commerce.Customer.Attributedefinition.AttributeResource(sourceContext);
            var productAttributeResource = new AttributeResource(sourceContext);

            var orderAttributeResource =
                new Api.Resources.Commerce.Orders.Attributedefinition.AttributeResource(sourceContext);


            var customerAttributes = await customerAttributeResource.GetAttributesAsync(pageSize: 200);
            
            foreach (var attr in customerAttributes.Items)
            {
                var at = new CustomerSeedAttribute()
                {
                    AttributeId = "0",
                    Name = attr.AdminName,
                    Id = attr.AttributeFQN,
                    DataType = attr.DataType,
                    AdminName = attr.AdminName,
                    Code = attr.AttributeCode,
                    DisplayGroup = attr.DisplayGroup,
                    InputType = attr.InputType,
                    IsActive = attr.IsActive,
                    IsRequired = attr.IsRequired,
                    IsVisible = attr.IsVisible,
                    Value = new List<string>()
                };

                var attrValues = await customerAttributeResource.GetAttributeVocabularyValuesAsync(attr.AttributeFQN);

                for (var i = 0; i < attrValues.Count; i++)
                {
                    at.Value.Insert(i,attrValues[i].Value);
                }

                var atList = new List<CustomerSeedAttribute> {at};
               
                try
                {
                   
                    var client =
                        new MozuClient<List<CustomerSeedAttribute>>().WithVerb("POST")
                            .WithResourceUrl(GetAttributesUrl())
                            .WithBody<List<CustomerSeedAttribute>>(atList);
                    client.WithContext(targetContext);
                    client.WithHeader("Origin", "https://t15026.sandbox.mozu.com");
                    client.WithHeader("Cookie",
                        "optimizelyEndUserId=oeu1411018217348r0.5324771166779101; _ga=GA1.2.650858733.1410971476; _fby_site_=1%7Cmozu.com%7C1450282855%7C1450282855%7C1450282855%7C1450283003%7C1%7C7%7C7; optimizelySegments=%7B%22400030121%22%3A%22gc%22%2C%22401210090%22%3A%22search%22%2C%22401990081%22%3A%22false%22%7D; optimizelyBuckets=%7B%7D; _mkto_trk=id:702-MYH-396&token:_mch-mozu.com-1411018220736-84702; mzrt-prod=Token=51e1f4ace9a94be9b3d4547e5c898a43&Expiration=635885634718160000&User=JZPwlFO2EMplF5BG0RYpQtv4GJwYyYZnvDc1GfBOLHzALAOCawAs/H/HVlo29IJYzN6OXWzRjoF7s/KevjgKyHLgM3rZeyiDgdKbRu3sNRduNhcbNeS7TmtTp18U2pcaXL0stXYwcf6tZ/ZNixuwdQ==; SBCONTEXT=site=&locale=&currency=&masterCatalog=&catalog=&tenant=15026&editmode=False; sb-admin-at-prod=at=XYBWKP4wHZowLp+CKVQvhmWot/HD1m2AKCuo5KIywfXoksklN9xHfy7IqF1NCTZJfBLyGUeR7iwnWHSYKje4ZMemBYF5iEpQOiLmVxQ2WiZrqZ/tEMATjo6pzOAf4YBGtE+iO6nne4OvHinyVeuZ6FOinZWAqzSXWy2dzuvibkKHIZLUTCpUe5brnhdTnfSsNDlXtETwRBaZ3ZaZn2F0ndBfQciC4iujLU4BrZYMmnRUx8masiFnDj9A6U/cTaCCjkEfds3IA6Y4xH1GR3bcBQjamud2BY4kxrCTLldFVEZy+vwM3QW7bfdYqDCS6yfl1FlmyCcTVGr1lb+0jHTcB5TXgkvtaq14o812TGLkaVtEBoPIECWN1psoP9zZhPnLlcM98xAuQX9vHw5Wai5XIqHdNGOGvEOJFYmImn1JUiPEKfgC5aAOhkwQXir94ZXvzmusArXafgT48tQNOQ/BW4Lkja2WxuXrKBKVHxtRl3q0jvpGCiFoHGe8YWEI7cVBQY7fvz3oZHsXDbysyY336XbTikkhMZfB8633U9d8ZWWq7SujIclMwP2zBMTHMIB7; __utmt=1; __utma=42390841.650858733.1410971476.1443800091.1452880328.85; __utmb=42390841.1.10.1452880328; __utmc=42390841; __utmz=42390841.1452880328.85.53.utmcsr=mozu.com|utmccn=(referral)|utmcmd=referral|utmcct=/login/to; mozuDevCenterAuth=AccessToken=Na4YG03Hrdk3qoKMiS4T/NM240x0USD2FjpFzjZsP0/7tBiGCjEf54fqyb0qzJQv/9XmvjdxnqrUsk2Jpm37Ol1MkEm94KOCQMGrdst02NKgXKJhepTdaaCAzpNBPAWEH4WSQn4WfNDRoJ9jZp3HoEViJ8oPGQPGAtC0CPY+piXQq1GtdKDwD67lynVvyfCVPNuPudiXkhPl0/OH06zw1vQoa4jcW2WhA8GUT71GZsUmLiow2+fCePjv3OtXd2UXNRSqVmch/uKqZn0mQWhPhwsKVgqiyq0hmWx0aZkifrC+5HtgL5Pk9T4fHG+1XBKEOxFmRn24PRiJ+Qiuu1WUTQ==&RefreshToken=51e1f4ace9a94be9b3d4547e5c898a43&AccessTokenExpiration=8D31DD68F6DDA80&RefreshTokenExpiration=8D31E9D9F265480");
                    var response = await client.ExecuteAsync();
                   
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            */

            //Seed Product attributes
            var prodAttrReader = new AttributeReader {Context = sourceContext, PageSize = 200};

            var prodAttrList = new List<Attribute>();

            while (await prodAttrReader.ReadAsync())
            {
                prodAttrList.AddRange(prodAttrReader.Items);
            }



        }

        [TestMethod]
        public async Task ReadProducts()
        {
            var apiContext = new ApiContext(TenantId, SiteId);
            var products = new List<Api.Contracts.ProductAdmin.Product>();
            var productReader = new ProductAdminReader
            {
                Context = apiContext,
                PageSize = 200, //Maximum records to be retured per page. Leave it at 200 for lesser iterations
                ResponseFields = "ProductCode" //Skip this assignment if you want all properties in the response.
            };

            while (await productReader.ReadAsync())
            {
                products.AddRange(productReader.Items);
            }
        }

        [TestMethod]
        public async Task Enable_Options()
        {
            var apiContext = new ApiContext(TenantId, SiteId);
            //var products = new List<Api.Contracts.ProductAdmin.Product>();
            var variationResource = new ProductVariationResource(apiContext);

            //var productReader = new ProductAdminReader
            //{
            //    Context = apiContext,
            //    PageSize = 200,
            //    ResponseFields = "ProductCode"
            //};

            //while (await productReader.ReadAsync())
            //{
            //    products.AddRange(productReader.Items);
            //}

            var prods =
                "AcadiaGreen-2034-50, AcadiaWhite-AC-41,AfricanViolet-2116-50,AnjouPear-AF-425,ApricotTint-086,BaffinIsland-CC-270,BlueHaze-1667,ButteredYam-AF-230,CalypsoBlue-727,CameoWhite-PM-25,Cotswold-AF-150,DillPickle-2147-40,DuneGrass-492,EquestrianGray-1553,HeartsDelight-1283,Hemlock-719,Hibiscus-2027-50,IcyMorn-457,Indigo-744,InnerBalance-1522,JetStream-814,KansasGrain-2160-60,KendallCharcoal-HC-166,LewivilleGreen-494,LightDaffodil-2027-60,LightPistachio-2034-60,LondonFog-1541,MaritimeWhite-OC-5,Mohair-1058,NaturalLinen-966,NorwichBrown-HC-19,OldWorld-2011-40,ParadiseBeach-911,PersianViolet-1419,RedParrot-1308,RivieraAzure-822,RoastedSesameSeed-2160-40,ShootingStar-304,SilverMarlin-2139-50,SunnyDays-172,SweetButter-171,SweetNectar-156,VanAlenGreen-HC-120,VanDeusenBlue-HC-156,Vellum-207";

            var prodArr = prods.Split(',');

            //await prodArr.ForEachAsync(10, async product =>
            //{



                foreach(var product in prodArr)
                {

                var productCode = product.Trim();

                var reader = new ProductVariationReader
                {
                    Context = apiContext,
                    ProductCode = productCode,
                    PageSize = 200
                };

                var variations = new List<ProductVariation>();

                while (await reader.ReadAsync())
                {
                    variations.AddRange(reader.Items);
                }

                //await variations.ForEachAsync(5, async v =>
                foreach(var v in variations)
                {
                    if (v.IsActive.GetValueOrDefault()) continue;
                    v.IsActive = true;
                    try
                    {
                        await
                            variationResource.UpdateProductVariationAsync(v, productCode, v.Variationkey,
                                "VariationProductCode,IsActive");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }
    }

    public class CustomerSeedAttribute
    {
        private string _valueType;
        private string _displayGroup;
        public string AttributeId { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string InputType { get; set; }

        public string DataType { get; set; }

        public string ValueType
        {
            get
            {
                if (String.IsNullOrEmpty(_valueType))
                {
                    return "AdminEntered";
                }
                return _valueType;
            }
            set
            {
                _valueType = value;
            }
        }
        public bool? IsOption { get; set; }
        public bool? IsExtra { get; set; }
        public string AdminName { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsVisible { get; set; }
        public bool? IsRequired { get; set; }

          public string DisplayGroup
        {
            get
            {
                if (String.IsNullOrEmpty(_displayGroup))
                {
                    return "Admin";
                }
                return _displayGroup;
            }
            set
            {
                _displayGroup = value;
            }
        }


         public bool? SearchableInStorefront { get; set; }

         public bool? SearchDisplayValue { get; set; }

        public bool? AllowFilteringAndSortingInStorefront { get; set; }

        public bool? IsProperty { get; set; }

        public IList<string> Value { get; set; } 

    //"id": "Tenant~lifetime-achievement",
    //"name": "Lifetime Achievement",
    //"code": "lifetime-achievement",
    //"inputType": "YesNo",
    //"dataType": "",
    //"valueType": "AdminEntered",
    //"isOption": false,
    //"isExtra": false,
    //"adminName": "Lifetime Achievement",
    //"isActive": false,
    //"isRequired": false,
    //"isVisible": false,
    //"displayGroup": "Admin",
    //"searchableInStorefront": true,
    //"searchDisplayValue": true,
    //"allowFilteringAndSortingInStorefront": true,
    //"isProperty": false,
    //"rows": "",
    //"attributeMetadata": [],
    //"regex": "",
    //"values": [],
    //"min": "",
    //"max": "",
    //"minDate": "",
    //"maxDate": ""
    }
}
