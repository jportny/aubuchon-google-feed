﻿using Autofac;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.ToolKit.Config;
using Mozu.AubuchonDataAdapter.Domain.Handlers;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class AppLogTests : BaseTest
    {
        private ILogHandler _logHandler;
        private IAppSetting _appSetting;
        IApiContext _apiContext;

        [TestInitialize]
        public void Init()
        {
            _appSetting = Container.Resolve<IAppSetting>();
            _logHandler = new LogHandler(_appSetting);
            _apiContext = new ApiContext(TenantId, SiteId);
        }


        [TestMethod]
        public void Should_Get_Logs()
        {
            var logs = _logHandler.List(TenantId, 25, null, null).Result;
            Assert.IsNotNull(logs);
        }
    }
}
