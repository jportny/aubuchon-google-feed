﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api.Contracts.ProductAdmin;
using Mozu.AubuchonDataAdapter.Domain.Contracts;
using Mozu.AubuchonDataAdapter.Domain.Mappers;
using Product = Mozu.Api.Contracts.ProductRuntime.Product;
using ProductPrice = Mozu.Api.Contracts.ProductRuntime.ProductPrice;


namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class MapperTests
    {
        //[TestMethod]
        //public void Should_Convert_Message_To_Xml_In_Memory()
        //{
        //    var product = new Product
        //    {
        //        Content =
        //            new ProductLocalizedContent
        //            {
        //                ProductName = "test",
        //                ProductShortDescription = "Short",
        //                ProductFullDescription = "Long"
        //            },
        //        Price = new ProductPrice { Msrp = 134}
        //    };
            
        //    var mapped = product.ToEdgeProductExportMessage("MozuWs", "MozuWs",StatusCode.New).ToXml();
        //}
    }
}
