﻿using Autofac;
using Mozu.Api.ToolKit.Config;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    public class BaseTest
    {
        public IContainer Container;
        protected int TenantId;
        protected int SiteId;
        public BaseTest()
        {
            Container = new Bootstrapper().Bootstrap().Container;
            var appSetting = Container.Resolve<IAppSetting>();
            TenantId = int.Parse(appSetting.Settings["TenantId"].ToString());
            SiteId = int.Parse(appSetting.Settings["SiteId"].ToString());
        }
    
    }
}
