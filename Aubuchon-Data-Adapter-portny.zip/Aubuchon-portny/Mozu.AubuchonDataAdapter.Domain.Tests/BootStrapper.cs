﻿using Autofac;
using Mozu.Api.ToolKit;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    public class Bootstrapper : AbstractBootstrapper
    {
        public override void InitializeContainer(ContainerBuilder containerBuilder)
        {

            base.InitializeContainer(containerBuilder);
            Integration.Scheduler.Bootstrapper.Register(containerBuilder);
            Domain.Bootstrapper.Register(containerBuilder);
        }

        public override void PostInitialize()
        {
            base.PostInitialize();

        }
    }
}
