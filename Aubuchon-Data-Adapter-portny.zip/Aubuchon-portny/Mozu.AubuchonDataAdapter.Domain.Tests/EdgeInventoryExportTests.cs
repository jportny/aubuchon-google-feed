﻿using System;
using System.Collections.Generic;
using Autofac;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.Contracts.ProductAdmin;
using Mozu.Api.Resources.Commerce.Catalog.Admin;
using Mozu.Api.ToolKit.Config;
using Mozu.AubuchonDataAdapter.Domain.Contracts;
using Mozu.AubuchonDataAdapter.Domain.Handlers;
using Mozu.AubuchonDataAdapter.Domain.Utility;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class EdgeInventoryExportTests : BaseTest
    {
        private IProductExportHandler _productExportHandler;
        private IAppSetting _appSetting;
        IApiContext _apiContext;

        [TestInitialize]
        public void Init()
        {

            _appSetting = Container.Resolve<IAppSetting>();
            _productExportHandler = new ProductExportHandler(_appSetting);
            _apiContext = new ApiContext(TenantId, SiteId);
        }

        [TestMethod]
        public void Should_Get_Inventory_Import_Message()
        {

            var productResource = new ProductResource(_apiContext);
            var prod = productResource.GetProductAsync("100002").Result;

            var locations = new List<LocationInventory>();

            var inventoryReader = new ProductLocationInventoryReader
            {
                Context = _apiContext,
                ProductCode = prod.ProductCode,
                PageSize = 200,ResponseFields = "Items(LocationCode)"
            };
            while (inventoryReader.ReadAsync().Result)
            {
                locations.AddRange(inventoryReader.Items);
            }


            prod.FillProductLocalizedImages(_apiContext).Wait();

            var xml = prod.BuildInventoryExportMessageAsync("MozuWs", "MozuWs", locations);
        }

        [TestMethod]
        public void Should_Get_Fileupload_Import_Message()
        {
            //_apiContext.CatalogId = 1;
            var productResource = new ProductResource(_apiContext);
            var prod = productResource.GetProductAsync("511720").Result;



            //var xml = prod.Content.ProductImages.BuildFileUploadExportMessageAsync(StatusCode.Active, "MozuWs", "MozuWs");
        }

      
    }
}
