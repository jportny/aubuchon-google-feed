﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.ToolKit.Config;
using Mozu.AubuchonDataAdapter.Domain.Handlers;
using Autofac;
using System;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class SftpTests : BaseTest
    {
        private IAppSetting _appSetting;
        IApiContext _apiContext;
       
        [TestInitialize]
        public void Init()
        {
            _appSetting = Container.Resolve<IAppSetting>();
            _apiContext = new ApiContext(TenantId, SiteId);
            
        }
        [TestMethod]
        public void Pull_Inventory_Advice_Message_Files() {
            var handler = new SftpHandler((string)_appSetting.Settings["JaggedPeakSFTPHost"], (string)_appSetting.Settings["JaggedPeakSFTPUser"].ToString(), (string)_appSetting.Settings["JaggedPeakSFTPPass"], (string)_appSetting.Settings["JaggedPeakSFTPKey"], Convert.ToInt32(_appSetting.Settings["JaggedPeakSFTPPort"]));

            handler.Pull((string)_appSetting.Settings["EdgeLocalInventoryAdvicePath"], (string)_appSetting.Settings["EdgeRemoteInventoryAdvicePath"]);
        }
        [TestMethod]
        public void Sync_Inv_From_Directory() {
          
        }
        [TestMethod]
        public void Should_Transfer_Order_Xml_To_JaggedPeak_Sftp()
        {
            var sftpHandler = new SftpHandler(_appSetting);
            sftpHandler.Push(@"C:\temp\payload13.txt", "/home/MozuAubuchonSFTP/inbox/Mozu/OrderImportConfirmation/");
        }
    }
}
