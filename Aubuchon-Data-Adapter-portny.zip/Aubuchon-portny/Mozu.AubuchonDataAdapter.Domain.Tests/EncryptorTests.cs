﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.AubuchonDataAdapter.Domain.Utility;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
     [TestClass]
    public class EncryptorTests
    {
         [TestMethod]
         public void EncryptString()
         {
             const string clearText = "Mozu12345";
             var encryptedString = SecureAppSetting.Encrypt(clearText);
             Console.WriteLine(encryptedString);

         }
    }
}
