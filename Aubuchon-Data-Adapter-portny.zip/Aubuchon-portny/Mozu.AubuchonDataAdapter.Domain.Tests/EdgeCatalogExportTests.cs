﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Autofac;
using Autofac.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mozu.Api;
using Mozu.Api.Contracts.Content;
using Mozu.Api.Contracts.ProductAdmin;
using Mozu.Api.Contracts.ProductRuntime;
using Mozu.Api.Resources.Commerce.Catalog.Admin.Attributedefinition;
using Mozu.Api.Resources.Commerce.Catalog.Storefront;
using Mozu.Api.Resources.Content.Documentlists;
using Mozu.Api.ToolKit.Config;
using Mozu.AubuchonDataAdapter.Domain.Contracts;
using Mozu.AubuchonDataAdapter.Domain.Handlers;
using Mozu.AubuchonDataAdapter.Domain.Utility;
using LocationInventory = Mozu.Api.Contracts.ProductAdmin.LocationInventory;
using Product = Mozu.Api.Contracts.ProductAdmin.Product;

namespace Mozu.AubuchonDataAdapter.Domain.Tests
{
    [TestClass]
    public class EdgeCatalogExportTests : BaseTest
    {
        private IProductExportHandler _productExportHandler;
        private IAppSetting _appSetting;
        IApiContext _apiContext;

        [TestInitialize]
        public void Init()
        {
            _appSetting = Container.Resolve<IAppSetting>();
            _productExportHandler = new ProductExportHandler(_appSetting);
            _apiContext = new ApiContext(TenantId, SiteId);
        }

        [TestMethod]
        public async Task GetProductsByAttributeFilter()
        {
            try
            {
                var res = new Api.Resources.Commerce.Catalog.Admin.ProductResource(_apiContext);
                var reader = new Mozu.Api.ToolKit.Readers.ProductAdminReader
                {
                    Context = _apiContext,
                    //Filter = String.Format("attributeFqn eq 'tenant~postliveedgeaccount'"),
                    PageSize = 200,SortBy = "updateDate desc"
                };

                var items = new List<Product>();
                while (await reader.ReadAsync())
                {
                    items.AddRange(reader.Items);
                    var hasAttr = items.Where(i => i.Properties.Any(p => p.AttributeFQN.Contains("postliveedge")));

                    foreach (var item in items)
                    {
                        var i = item.Properties.FirstOrDefault(p => p.AttributeFQN.Contains("postliveedge"));
                        if(i == null) continue;
                        
                        item.Properties.Remove(i);
                        await res.UpdateProductAsync(item, item.ProductCode);
                    }
                }

                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        [TestMethod]
        public async Task Should_Get_Catalog_Import_Message()
        {
            var product = await _productExportHandler.GetProduct(_apiContext, "100002");
            var xml = product.BuildProductExportMessageAsync("MozuWs","MozuWs");
        }

        [TestMethod]
        public async Task Should_Update_Edge_Catalog()
        {
            var product = await _productExportHandler.GetProduct(_apiContext, "TEST001");
            await _productExportHandler.ExportProductAsync(_apiContext, product);
        }

        [TestMethod]
        public async Task Should_Export_Product()
        {
            var productHandler = new ProductExportHandler(_appSetting);
            var product = await productHandler.GetProduct(_apiContext, "GENERIC");
            var productStoreResource = new ProductResource(_apiContext);
           
            var sfProd = productStoreResource.GetProductAsync(product.ProductCode).Result;//,responseFields:"Content(ProductImages)").Result;
            
            //Get images form storefront product
            var images = sfProd.Content.ProductImages;
            var productImages = new List<ProductLocalizedImage>();

           
            if (images != null)
            {
               
                var documentResource = new DocumentResource(_apiContext);
                foreach (var image in images)
                {
                    var imageUrl = image.ImageUrl ??
                                  String.Format("//cdn-sb.mozu.com/{0}-m1/cms/files/{1}", _apiContext.TenantId,
                       image.CmsId);
                    var document = await documentResource.GetDocumentAsync("files@mozu", image.CmsId);
                    
                    productImages.Add(new ProductLocalizedImage{
                        CmsId = image.CmsId,
                        ImageLabel = document.Name,
                        //ImageUrl = image.ImageUrl.Replace(image.CmsId, document.Name)
                        ImageUrl = imageUrl.Replace(image.CmsId, document.Name)
                    });
                }
                product.Content.ProductImages = productImages;
            }

            //Get Locations for Product
            var locations = new List<LocationInventory>();

            var inventoryReader = new ProductLocationInventoryReader
            {
                Context = _apiContext,
                ProductCode = product.ProductCode,
                PageSize = 200,
                ResponseFields = "Items(LocationCode)"
            };
            while (await inventoryReader.ReadAsync())
            {
                locations.AddRange(inventoryReader.Items);
            }


            await productHandler.ExportFileuploadAsync(productImages);
            await productHandler.ExportInventoryAsync(_apiContext,product, locations);
            await productHandler.ExportProductAsync(_apiContext,product);
        }
    }
}
